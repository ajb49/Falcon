prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>33
,p_name=>'Work Storage'
,p_alias=>'WORK-STORAGE'
,p_page_mode=>'MODAL'
,p_step_title=>'Work Storage'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding:t-DeferredRendering:t-PageBody--noContentPadding'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231022091433'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(80029988525144575049)
,p_name=>'HISTORY'
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select task_name||'' | ''',
'                ||(select listagg (name_file,'' | '') within group (order by name_file) from project_attachments pa where pa.proid=pd.proid) l',
', case when (select count(proid) from project_attachments pa where pa.proid = pd.proid) > 0 then ''<span aria-hidden="true" class="fa fa-paperclip fam-check fam-is-success"></span>''',
'when (select count(proid) from project_attachments pa where pa.proid = pd.proid) <= 0 then ''<span class="fa fa-plus-circle-o" aria-hidden="true"></span>''',
'else null end attachments',
', proid',
'from project_details pd',
'where lower(task_name) like lower(''%''||:P33_SEARCH||''%'')',
'or proid in (select proid from project_attachments where filename like lower(''%''||:P33_SEARCH||''%'')',
'or name_file like lower(''%''||:P33_SEARCH||''%'')',
'or INSTR(lower(TO_CLOB (ATTACHEMENT_FILE)), lower(''''||:P33_SEARCH||'''')) > 0)',
'order by 1;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P33_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80029988685527575050)
,p_query_column_id=>1
,p_column_alias=>'L'
,p_column_display_sequence=>10
,p_column_heading=>'L'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80185191465906155905)
,p_query_column_id=>2
,p_column_alias=>'ATTACHMENTS'
,p_column_display_sequence=>20
,p_column_heading=>'Attachments'
,p_column_format=>'PCT_GRAPH:::'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::P17_PROID:#PROID#'
,p_column_linktext=>'#ATTACHMENTS#'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80185191583641155906)
,p_query_column_id=>3
,p_column_alias=>'PROID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80185191180063155902)
,p_name=>'P33_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(80029988525144575049)
,p_prompt=>'Search'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT task_name suggestion',
'FROM project_details',
'UNION ALL',
'SELECT name_file',
'FROM project_attachments',
'UNION ALL',
'SELECT filename',
'FROM project_attachments',
'ORDER BY 1;'))
,p_cSize=>30
,p_grid_column=>8
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80185191297010155903)
,p_name=>'HIST'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P33_SEARCH'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80185191387390155904)
,p_event_id=>wwv_flow_imp.id(80185191297010155903)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(80029988525144575049)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80185194269389155933)
,p_name=>'RR'
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80185194307489155934)
,p_event_id=>wwv_flow_imp.id(80185194269389155933)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(80029988525144575049)
);
wwv_flow_imp.component_end;
end;
/
