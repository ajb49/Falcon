prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>42
,p_name=>'Task Calender'
,p_alias=>'TASK-CALENDER'
,p_step_title=>'Task Calender'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* //If weekend is needed to mark ',
'.fc .fc-daygrid-day.fc-day-sat {',
'  background-color: #309fdb1a;',
'}',
'.fc .fc-daygrid-day.fc-day-fri {',
'  background-color: #f3f7811a;',
'} */',
'',
'.fc-day-today {',
' background-color: rgb(181, 222, 120)/*#45698fd2*/ !important;',
'}',
'',
'',
'.fc-day-past {',
'    background-color: rgba(202, 195, 172, 0.481);',
'}',
'',
'.fc-day-future {',
'    background-color: rgb(243, 244, 246);',
'}',
'',
'.t-Footer {',
'    display: none;   ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231024191147'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2867556088933304608)
,p_plug_name=>'CALN'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2380531398061787611)
,p_plug_name=>'Param'
,p_parent_plug_id=>wwv_flow_imp.id(2867556088933304608)
,p_region_css_classes=>'region-col'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>2
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2867556148474304609)
,p_plug_name=>'TASK_VIEW'
,p_parent_plug_id=>wwv_flow_imp.id(2867556088933304608)
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pd.TASK_NAME,',
'       pd.START_FROM,',
'       pd.END_TO,',
'       pd.FORECAST,',
'       pd.STATUS,',
'       pd.PROJECT_ID,',
'       pd.PERSON,',
'       pd.PROID,',
'       pd.INS_BY,',
'       pd.INS_DATE,',
'       pd.UPD_BY,',
'       pd.UPD_DATE,',
'       pd.UPD_DONE,',
'       pd.STS_BY,',
'       pd.TEAM_ID,',
'       pd.APPROVAL,',
'       sysdate today,',
'       case',
'        when pd.status = ''0'' then ''apex-cal-blue'' --running',
'        when pd.status = ''2'' then ''apex-cal-red'' --overdue',
'        when pd.status = ''3'' then ''apex-cal-light-gray'' --halt --external css used',
'        when pd.status = ''4'' then ''apex-cal-white'' --cancel',
'        -- when pd.status = ''5'' then null',
'        -- when pd.status = ''1'' then null',
'        end css_class',
'  from PROJECT_DETAILS pd, USER_TASKS ut',
'  where pd.proid = ut.proid',
' and pd.status NOT IN (1,5)',
'  and (pd.team_id = :P42_TEAM or :P42_TEAM is null)',
'  and (pd.project_id = :P42_PROJECT or :P42_PROJECT is null)',
'  and ut.userid = :P42_USERID;'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P42_TEAM,P42_PROJECT,P42_USERID'
,p_attribute_01=>'START_FROM'
,p_attribute_02=>'END_TO'
,p_attribute_03=>'TASK_NAME'
,p_attribute_11=>'month:week:day:list:navigation'
,p_attribute_13=>'Y'
,p_attribute_14=>'CSS_CLASS'
,p_attribute_17=>'Y'
,p_attribute_18=>'00'
,p_attribute_19=>'Y'
,p_attribute_20=>'9'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2380530613524787604)
,p_name=>'P42_TEAM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2380531398061787611)
,p_item_default=>':BIND_TEAM_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Call Team'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TEAM'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :BIND_USER_ROLE IN (''1000'',''1001'') THEN',
'RETURN TRUE;',
'ELSE ',
'RETURN FALSE;',
'END IF;'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2380530845584787606)
,p_name=>'P42_PROJECT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2380531398061787611)
,p_prompt=>'Call Project'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PROJECT_NAME'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROJECT_ID,  PROJECT_NAME',
'                    ||'': ''',
'                    ||TO_CHAR(CHECK_OUT,''DD-MON-YY'')',
'                    ||'' [ ''',
'                    ||(SELECT nvl(team_name,''No Team'') FROM teams WHERE teams.team_id = projects.team_id)',
'                    ||'' ]'' PROJECT_NAME ',
'from PROJECTS ',
'where (TEAM_ID = :BIND_TEAM_ID ',
'OR ',
'project_id in (SELECT project_id FROM projects WHERE project_id in (select project_id from project_details where proid in (select proid from user_tasks where userid = :BIND_USER_ID)))',
') ',
'AND STATUS IN (''Y'')',
'-- select PROJECT_ID, PROJECT_NAME||'': ''||TO_CHAR(CHECK_OUT,''DD-MON'') PROJECT_NAME ',
'-- from PROJECTS ',
'-- where (TEAM_ID = :BIND_TEAM_ID ',
'-- OR ',
'-- project_id in (SELECT project_id FROM projects WHERE project_id in (select project_id from project_details where proid in (select proid from user_tasks where userid = :BIND_USER_ID)))',
'-- ) ',
'-- AND STATUS IN (''Y'');'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2380531134619787609)
,p_name=>'P42_USERID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2380531398061787611)
,p_prompt=>'User'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'USERNAME(SIMPLE)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT full_name||'' (''||email||'' - ''||id_no||'')'' d, userid r',
'FROM user_tables',
'where status IN (''Y'',''N'')',
'order by 1 asc'))
,p_cSize=>30
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :BIND_USER_ROLE IN (''1000'') THEN',
'RETURN TRUE;',
'ELSE ',
'RETURN FALSE;',
'END IF;'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2380530906638787607)
,p_name=>'rr'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P42_TEAM,P42_PROJECT,P42_USERID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2380531045265787608)
,p_event_id=>wwv_flow_imp.id(2380530906638787607)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2867556148474304609)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5117374114803356511)
,p_name=>'RFS'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P42_TODAY,P42_STS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2380531269357787610)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GotUser'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P42_USERID := :BIND_USER_ID;',
':P42_TEAM := :BIND_TEAM_ID;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>2380531269357787610
);
wwv_flow_imp.component_end;
end;
/
