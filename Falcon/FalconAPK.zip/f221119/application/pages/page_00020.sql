prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Add Members [Team]'
,p_alias=>'ADD-MEMBERS-TEAM'
,p_step_title=>'Add Members [Team]'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Footer {',
'    ',
'    display: none;',
'    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231018060730'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28720458062953109049)
,p_plug_name=>'ADD Member'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-showMaximizeButton:t-Region--showIcon:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(27645544873689606414)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_display_column=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28720456644115109035)
,p_plug_name=>'TEAM_BLOCK'
,p_parent_plug_id=>wwv_flow_imp.id(28720458062953109049)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28720456861895109037)
,p_plug_name=>'MEMBER_BLOCK'
,p_parent_plug_id=>wwv_flow_imp.id(28720458062953109049)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645535011037606409)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TEAM_MEMBER_ID,',
'       TEAM_ID,',
'       USERID',
'  from TEAM_MEMBERS',
'  where team_id = :P20_TEAM_ID;'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P20_TEAM_ID'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'MEMBER_BLOCK'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28720457052955109039)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_display_condition_type=>'FUNCTION_BODY'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :BIND_USER_ROLE IN (1000,1001) THEN',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;'))
,p_display_condition2=>'PLSQL'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28720457195856109040)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28720457317444109042)
,p_name=>'TEAM_MEMBER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEAM_MEMBER_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28720457455205109043)
,p_name=>'TEAM_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEAM_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28720457590467109044)
,p_name=>'USERID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Add Members For Team'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct full_name||'' (''||email||'' - ''||id_no||'')'' d, ut.userid r',
'FROM user_tables ut, users_role ur',
'where ut.userid = ur.userid',
'AND ut.status IN (''Y'',''N'')',
'and :BIND_USER_ROLE IN (1000,1001)',
'and :BIND_USER_ID IS NOT NULL',
'order by 1 asc'))
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(28720456979683109038)
,p_internal_uid=>28720456979683109038
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {  ',
'   config.defaultGridViewOptions = {  ',
'   footer: false',
'}  ',
'return config;  ',
'}  '))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(29488015968781555204)
,p_interactive_grid_id=>wwv_flow_imp.id(28720456979683109038)
,p_static_id=>'294880160'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(29488016159508555204)
,p_report_id=>wwv_flow_imp.id(29488015968781555204)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29488016623369555213)
,p_view_id=>wwv_flow_imp.id(29488016159508555204)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(28720457052955109039)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29488017905173555219)
,p_view_id=>wwv_flow_imp.id(29488016159508555204)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(28720457317444109042)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29488018846541555222)
,p_view_id=>wwv_flow_imp.id(29488016159508555204)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(28720457455205109043)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29488019762550555225)
,p_view_id=>wwv_flow_imp.id(29488016159508555204)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(28720457590467109044)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29494189347610735514)
,p_name=>'P20_TEAM_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28720456644115109035)
,p_item_default=>':BIND_TEAM_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Team Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT team_name||'' [''||(select full_name||'' - ''||id_no from user_tables i where i.userid = m.team_leader)||'']'' d, team_id r',
'FROM teams m'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29494189438631735515)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_TEAM_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29494189548156735516)
,p_event_id=>wwv_flow_imp.id(29494189438631735515)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28720456861895109037)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28720457292818109041)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(28720456861895109037)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'MEMBER_BLOCK - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P20_TEAM_ID is not null then',
'    case :APEX$ROW_STATUS',
'    when ''C'' then',
'        DECLARE',
'            NEW_PK            number :=  NULL;',
'        BEGIN',
'',
'            SELECT MAX (team_member_id)',
'              INTO NEW_PK',
'              FROM team_members;',
'            ',
'            IF NEW_PK IS NULL THEN',
'                NEW_PK := 1000;',
'            ELSE',
'                NEW_PK := NEW_PK + 1;',
'            END IF;',
'            ',
'            :TEAM_MEMBER_ID := NEW_PK;',
'            :TEAM_ID := :P20_TEAM_ID;',
'        insert into team_members ( team_member_id, team_id, userid )',
'        values ( :TEAM_MEMBER_ID, :P20_TEAM_ID, :USERID );',
'        END;',
'        ',
'    when ''U'' then',
'    :TEAM_ID := :P20_TEAM_ID;',
'        update team_members',
'           set team_id  = :P20_TEAM_ID,',
'               userid = :USERID',
'         where team_member_id  = :TEAM_MEMBER_ID;',
'    when ''D'' then',
'        delete team_members',
'         where team_member_id = :TEAM_MEMBER_ID;',
'    end case;',
'else null;',
'end if;',
'end;'))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28720457292818109041
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(30534585974038991609)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'New'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_internal_uid=>30534585974038991609
);
wwv_flow_imp.component_end;
end;
/
