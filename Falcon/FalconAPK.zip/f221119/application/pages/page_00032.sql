prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>32
,p_name=>'Task Approval'
,p_alias=>'TASK-APPROVAL'
,p_step_title=>'Task Approval'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Footer {',
'    ',
'    display: none;',
'    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231024203646'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48131071885465786503)
,p_plug_name=>'Task Approval'
,p_icon_css_classes=>'fa-check-square-o'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645511538145606399)
,p_plug_display_sequence=>10
,p_menu_id=>wwv_flow_imp.id(27645441599237606364)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(27645619693166606450)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78667104931676916438)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76202585696140872464)
,p_plug_name=>'Project Task Preview'
,p_parent_plug_id=>wwv_flow_imp.id(78667104931676916438)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645535011037606409)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TASK_NAME,',
'       START_FROM,',
'       END_TO,',
'       FORECAST,',
'       STATUS,',
'       PROJECT_ID,',
'       PERSON,',
'       PROID,',
'       ins_by,',
'       ins_date,',
'       upd_by,',
'       upd_date,',
'       upd_done,',
'       '''' attachment,',
'       team_id,',
'       approval,',
'       (select full_name||'' ''||id_no||'' (''||email||'')'' from user_tables ut where ut.userid = i.sts_by) submit_by,',
'       (SELECT COUNT(*) FROM USER_TASKS j WHERE j.proid = i.proid) PERSONS,',
'        case when status not in (1,3)',
'        then (SELECT case when round((sysdate - start_from)+1) < 0 ',
'        then null else round((sysdate - start_from)+1) end ',
'        FROM project_details j  ',
'        WHERE i.proid = j.proid)',
'        else null end||''/''||to_char(trunc(end_to - start_from)+1)||'' Days'' Total_Time_Taken ',
'  from PROJECT_DETAILS i',
'  where status not in (''1'',''3'',''4'',''0'',''2'')',
'  and proid in ((select proid from user_tasks where team_id IN :BIND_TEAM_ID))'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Project Task Preview'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5117374616894356516)
,p_name=>'SUBMIT_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUBMIT_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Submit By'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48131071664873786501)
,p_name=>'APPROVAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPROVAL'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Approval'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'STATIC'
,p_lov_source=>'STATIC:Proceed;1,Undo;0'
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76008007570676150948)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_display_condition_type=>'FUNCTION_BODY'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE IN (''1002'') THEN',
'RETURN FALSE;',
'ELSE',
'RETURN TRUE;',
'END IF;',
'END;'))
,p_display_condition2=>'PLSQL'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76008007650494150949)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_display_condition_type=>'FUNCTION_BODY'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE IN (''1002'') THEN',
'RETURN FALSE;',
'ELSE',
'RETURN TRUE;',
'END IF;',
'END;'))
,p_display_condition2=>'PLSQL'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76008009164084150964)
,p_name=>'PERSONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSONS'
,p_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Persons'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RR,4:P4_PROID:&PROID.'
,p_link_text=>'&PERSONS.'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76008009375261150966)
,p_name=>'TOTAL_TIME_TAKEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_TIME_TAKEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Total Time Taken'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76202587053073872475)
,p_name=>'TASK_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Task Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_readonly_condition=>'BIND_USER_ROLE'
,p_readonly_condition2=>'1002'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76202588142396872480)
,p_name=>'START_FROM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_FROM'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Project Start Date'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
,p_format_mask=>'DD-MON-RR'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'EXPRESSION'
,p_default_language=>'PLSQL'
,p_default_expression=>'to_char(current_timestamp,''DD-MON-RR'')'
,p_duplicate_value=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_readonly_condition=>'BIND_USER_ROLE'
,p_readonly_condition2=>'1002'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76202589174734872481)
,p_name=>'END_TO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_TO'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Project End Date'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'START_FROM'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
,p_format_mask=>'DD-MON-RR'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_readonly_condition=>'BIND_USER_ROLE'
,p_readonly_condition2=>'1002'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76202590212607872482)
,p_name=>'FORECAST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FORECAST'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Forecast'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
,p_format_mask=>'DD-MON-RR'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_readonly_condition=>'BIND_USER_ROLE'
,p_readonly_condition2=>'1002'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76202591152619872482)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(27651661124332706306)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'0'
,p_duplicate_value=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76202592152624872483)
,p_name=>'PROJECT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Project Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(27648500739927683671)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_readonly_condition=>'BIND_USER_ROLE'
,p_readonly_condition2=>'1002'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76202593173834872483)
,p_name=>'PERSON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSON'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76202594133427872484)
,p_name=>'PROID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76413308594558580358)
,p_name=>'INS_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INS_BY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76413308710075580359)
,p_name=>'INS_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INS_DATE'
,p_data_type=>'TIMESTAMP'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'INS'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76413308743894580360)
,p_name=>'UPD_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPD_BY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(76413308825536580361)
,p_name=>'UPD_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPD_DATE'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>210
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(82950774561456366829)
,p_name=>'UPD_DONE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPD_DONE'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'N'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(83298696892261087230)
,p_name=>'ATTACHMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ATTACHMENT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Attachment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RR,17:P17_PROID:&PROID.'
,p_link_text=>'<span class="fa fa-paperclip" aria-hidden="true"></span>'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(86286217880761824429)
,p_name=>'TEAM_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEAM_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Team Id'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>150
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P32_TEAM_ID'
,p_duplicate_value=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(76202586141867872465)
,p_internal_uid=>76202586141867872465
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_no_data_found_message=>'No Task for approval'
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>false
,p_download_formats=>null
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {  ',
'',
'   config.defaultGridViewOptions = {  ',
'',
'   footer: false',
'',
'}  ',
'',
'return config;  ',
'',
'}  '))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(76202586566064872465)
,p_interactive_grid_id=>wwv_flow_imp.id(76202586141867872465)
,p_static_id=>'280700677'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(76202586737682872465)
,p_report_id=>wwv_flow_imp.id(76202586566064872465)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1765237453775387)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(5117374616894356516)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(48131108087826792918)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(48131071664873786501)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>75.9
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202587419403872479)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(76202587053073872475)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>285
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202588602003872481)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(76202588142396872480)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>111
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202589551936872481)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(76202589174734872481)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>117
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202590532669872482)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(76202590212607872482)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>94
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202591539223872482)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(76202591152619872482)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>93
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202592535534872483)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(76202592152624872483)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>144
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202593569605872483)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(76202593173834872483)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202594600733872484)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(76202594133427872484)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76202617056950875223)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(76008007570676150948)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76242093293806974154)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(76008009164084150964)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>59
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76260505239284805574)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(76008009375261150966)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>109
,p_sort_order=>2
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76444557538261866364)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(76413308594558580358)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76444558514382866367)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(76413308710075580359)
,p_is_visible=>false
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76444559358303866370)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(76413308743894580360)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(76444560272127866373)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(76413308825536580361)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(82952130000439868298)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(82950774561456366829)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(83300637837641619362)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(83298696892261087230)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(86286443972174827015)
,p_view_id=>wwv_flow_imp.id(76202586737682872465)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(86286217880761824429)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76413308246249580355)
,p_plug_name=>'Block3'
,p_parent_plug_id=>wwv_flow_imp.id(78667104931676916438)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>50
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48132533514627924846)
,p_button_sequence=>10
,p_button_name=>'CreateNewProject'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Create New Project'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v___leader  number;',
'v___sub     number;',
'BEGIN',
'SELECT COUNT(team_leader)',
'INTO v___leader',
'FROM teams',
'WHERE team_leader = :BIND_USER_ID;',
'',
'SELECT COUNT(sub_leader)',
'INTO v___sub',
'FROM teams',
'WHERE sub_leader = :BIND_USER_ID;',
'',
'IF (:BIND_USER_ROLE in (1000,1001)) OR (v___leader > 0) OR (v___sub > 0) THEN',
'RETURN TRUE;',
'ELSE ',
'RETURN FALSE;',
'END IF;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48132533138113924846)
,p_button_sequence=>20
,p_button_name=>'HitONUser'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Hit On User'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v___leader  number;',
'v___sub     number;',
'BEGIN',
'SELECT COUNT(team_leader)',
'INTO v___leader',
'FROM teams',
'WHERE team_leader = :BIND_USER_ID;',
'',
'SELECT COUNT(sub_leader)',
'INTO v___sub',
'FROM teams',
'WHERE sub_leader = :BIND_USER_ID;',
'',
'IF (:BIND_USER_ROLE in (1000,1001)) OR (v___leader > 0) OR (v___sub > 0) THEN',
'RETURN TRUE;',
'ELSE ',
'RETURN FALSE;',
'END IF;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48132532740614924845)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(48131071885465786503)
,p_button_name=>'Refresh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645617343518606449)
,p_button_image_alt=>'Refresh'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76413309772437580360)
,p_name=>'P32_USERID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76413308246249580355)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76413309874382580361)
,p_name=>'P32_TIMESTAMP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(76413308246249580355)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86286219430659824435)
,p_name=>'P32_TEAM_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(76413308246249580355)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(48132530146443924843)
,p_tabular_form_region_id=>wwv_flow_imp.id(76202585696140872464)
,p_validation_name=>'NoLessStart'
,p_validation_sequence=>10
,p_validation=>'TO_DATE(:START_FROM,''DD-MON-RR'') <= TO_DATE(:END_TO,''DD-MON-RR'')'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'#END_TO# must have an accurate value.'
,p_associated_column=>'END_TO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(48132530591829924844)
,p_tabular_form_region_id=>wwv_flow_imp.id(76202585696140872464)
,p_validation_name=>'NoGreaterEnd'
,p_validation_sequence=>20
,p_validation=>'TO_DATE(:START_FROM,''DD-MON-RR'') <= TO_DATE(:END_TO,''DD-MON-RR'')'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'#START_FROM# must have an accurate value.'
,p_associated_column=>'START_FROM'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(48132530965513924844)
,p_tabular_form_region_id=>wwv_flow_imp.id(76202585696140872464)
,p_validation_name=>'MustInclude'
,p_validation_sequence=>30
,p_validation=>'START_FROM'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# must have a value.'
,p_associated_column=>'START_FROM'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(48132531312046924844)
,p_tabular_form_region_id=>wwv_flow_imp.id(76202585696140872464)
,p_validation_name=>'MustInclude_1'
,p_validation_sequence=>40
,p_validation=>'END_TO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# must have a value.'
,p_associated_column=>'END_TO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(48132531750513924844)
,p_tabular_form_region_id=>wwv_flow_imp.id(76202585696140872464)
,p_validation_name=>'MustInclude_1_1'
,p_validation_sequence=>50
,p_validation=>'TASK_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# must have a value.'
,p_associated_column=>'TASK_NAME'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48132535749938924848)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48132536269348924848)
,p_event_id=>wwv_flow_imp.id(48132535749938924848)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(76202585696140872464)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48132536688280924848)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P32_ROWS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48132537163636924849)
,p_event_id=>wwv_flow_imp.id(48132536688280924848)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(76202585696140872464)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(48132532017030924844)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(76202585696140872464)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Project Task Preview - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    case :APEX$ROW_STATUS',
'    when ''C'' then',
'DECLARE',
'    NEW_PK            number :=  NULL;',
'BEGIN',
'    SELECT MAX (proid)',
'      INTO NEW_PK',
'      FROM project_details;',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;   ',
'    --:PROID := NEW_PK;',
'insert into PROJECT_DETAILS ( PROID, TASK_NAME, START_FROM, END_TO, FORECAST, STATUS, PROJECT_ID, PERSON,ins_by,ins_date,upd_by,upd_date,team_id )',
'        values ( NEW_PK, :TASK_NAME, TO_DATE(:START_FROM,''DD-MON-RR''), TO_DATE(:END_TO,''DD-MON-RR''), TO_DATE(:FORECAST,''DD-MON-RR''), :STATUS, :PROJECT_ID, :PERSON,',
'        :BIND_USER_ID, CURRENT_TIMESTAMP, NULL, NULL,:TEAM_ID );',
'IF :STATUS = 1 THEN',
'UPDATE project_details SET upd_done = CURRENT_TIMESTAMP where proid = :PROID;',
'ELSE null;',
'end if;',
'',
'END;',
'    ',
'        --returning PROID into :PROID;',
'    when ''U'' then',
'        ----------------------------------------which time task is done',
'           IF :APPROVAL = ''0'' THEN',
'            UPDATE project_details SET upd_done = NULL where proid = :PROID;',
'           ELSIF :APPROVAL = ''1'' THEN',
'            UPDATE project_details SET upd_done = upd_date where proid = :PROID;',
'             end if;',
'---------------------------------------------------------',
'        update PROJECT_DETAILS',
'           set PROID = :PROID,',
'            TASK_NAME = :TASK_NAME,',
'             START_FROM = TO_DATE(:START_FROM,''DD-MON-RR''), ',
'             END_TO = TO_DATE(:END_TO,''DD-MON-RR''), ',
'             FORECAST = TO_DATE(:FORECAST,''DD-MON-RR''), ',
'             STATUS = :STATUS, ',
'             PROJECT_ID = :PROJECT_ID, ',
'             PERSON = :PERSON,',
'             UPD_BY = :P32_USERID,',
'             UPD_DATE = CURRENT_TIMESTAMP,',
'             TEAM_ID = :TEAM_ID,',
'             APPROVAL = :APPROVAL',
'         where PROID  = :PROID;',
'         --------------------------------if approve then making it done if not then making it pending',
'          IF :APPROVAL = ''1'' THEN ',
'          UPDATE project_details SET STATUS = ''1'' WHERE PROID = :PROID;',
'          ELSIF :APPROVAL = ''0'' THEN',
'          UPDATE project_details SET STATUS = ''0'' WHERE PROID = :PROID;',
'          ELSE ',
'          NULL;',
'          END IF;',
'',
'        ----------------------------------------who change the status    ',
'            IF :STATUS IN (''0'',''1'',''2'',''3'',''4'',''5'') THEN',
'            UPDATE project_details SET sts_by = :BIND_USER_ID WHERE proid = :PROID;',
'            ELSE null;',
'            END IF;',
'    when ''D'' then',
'        delete PROJECT_DETAILS',
'         where PROID = :PROID;',
'IF :STATUS = 1 THEN',
'UPDATE project_details SET upd_done = CURRENT_TIMESTAMP where proid = :PROID;',
'ELSE null;',
'end if;',
'    end case;',
'end;'))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>48132532017030924844
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(48132535323365924847)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P32_USERID := :BIND_USER_ID;',
':P32_TIMESTAMP := CURRENT_TIMESTAMP;',
':P32_TEAM_ID := :BIND_TEAM_ID;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>48132535323365924847
);
wwv_flow_imp.component_end;
end;
/
