prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Remained Day'
,p_alias=>'REMAINED-DAY'
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(27645442358579606365)
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding:t-DeferredRendering:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm:t-PageBody--noContentPadding'
,p_dialog_height=>'500'
,p_dialog_width=>'1200'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230802113419'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28714911266824984413)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT project_name||'' (''||project_description||'') - From ''||to_char(check_in,''dd/mm/yyyy'')||'' To ''||to_char(check_out,''dd/mm/yyyy'') details',
', trunc(check_out - sysdate)+1||'' Days'' remained',
'FROM PROJECTS',
'WHERE (CHECK_OUT - SYSDATE <= 7) and (CHECK_OUT - SYSDATE >0)',
'AND COMMENTS = ''N''',
'AND STATUS = ''Y'';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Remained Day'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(28714911328437984413)
,p_name=>'Remained Day'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_show_search_bar=>'N'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_internal_uid=>28714911328437984413
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(28714911757182984414)
,p_db_column_name=>'DETAILS'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Details'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(28280791268584655546)
,p_db_column_name=>'REMAINED'
,p_display_order=>11
,p_column_identifier=>'C'
,p_column_label=>'Remained'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(28716617366379022140)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'287166174'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DETAILS:REMAINED:'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(36307536851115800504)
,p_name=>'By Who'
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''Task: ''||task_name||'' is ''||decode(status,''0'',''Pending'',''1'',''Done'',''2'',''Overdued'',''3'',''Halted'',''4'',''Canceled'',null)||'' by ''||(select full_name from user_tables ut where ut.userid=pd.sts_by)||'' on ''||to_char(upd_date,''DD-MON Day'') time_occured',
'FROM project_details pd',
'WHERE TO_CHAR(upd_date,''DD-MON-YY'') between TO_CHAR(sysdate,''DD-MON-YY'') and TO_CHAR(sysdate - 30,''DD-MON-YY'')',
'AND STS_BY IS NOT NULL;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>90000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(36328484045419107902)
,p_query_column_id=>1
,p_column_alias=>'TIME_OCCURED'
,p_column_display_sequence=>10
,p_column_heading=>'Time Occured'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36370745224793908201)
,p_plug_name=>'&nbsp'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-showMaximizeButton:t-Region--showIcon:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(27645544873689606414)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(36307536851115800504)
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36370745378698908202)
,p_name=>'P14_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(36370745224793908201)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp.component_end;
end;
/
