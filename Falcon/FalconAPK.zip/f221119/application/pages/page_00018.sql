prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Auth'
,p_alias=>'AUTH'
,p_page_mode=>'MODAL'
,p_step_title=>'Authentication'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231021093635'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28283055865521295689)
,p_plug_name=>'Auth'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'SELECT ROWID, ROLEID, USERID, TEAM_ID FROM USERS_ROLE;'
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28283058379401295691)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645481003320606385)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28283058798150295691)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28283058379401295691)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28283060148752295692)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(28283058379401295691)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P18_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28283060549387295692)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(28283058379401295691)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P18_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28283060986357295692)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(28283058379401295691)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P18_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(725877444217256307)
,p_name=>'P18_TEAM_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(28283055865521295689)
,p_item_source_plug_id=>wwv_flow_imp.id(28283055865521295689)
,p_prompt=>'Team'
,p_source=>'TEAM_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'TEAM'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct (select team_name',
'                        ||'' TL: ''',
'                        ||(select full_name from user_tables ut where ut.userid = tm.team_leader) ',
'                 from teams tm where tm.team_id = ur.team_id) d, team_id r',
'from users_role ur',
'where team_id in ',
'(select team_id from teams where team_id not in ',
'(select team_id from team_members where userid = :P18_USERID))'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28283056292600295689)
,p_name=>'P18_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(28283055865521295689)
,p_item_source_plug_id=>wwv_flow_imp.id(28283055865521295689)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rowid'
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28283056603259295690)
,p_name=>'P18_ROLEID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(28283055865521295689)
,p_item_source_plug_id=>wwv_flow_imp.id(28283055865521295689)
,p_prompt=>'Role Name'
,p_source=>'ROLEID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ROLE'
,p_lov=>'SELECT ROLEID, ROLENAME FROM ROLE_TABLES;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28283057062980295690)
,p_name=>'P18_USERID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28283055865521295689)
,p_item_source_plug_id=>wwv_flow_imp.id(28283055865521295689)
,p_prompt=>'User'
,p_source=>'USERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'USERNAME(SIMPLE)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT full_name||'' (''||email||'' - ''||id_no||'')'' d, userid r',
'FROM user_tables',
'where status IN (''Y'',''N'')',
'order by 1 asc'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28283058851641295691)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28283058798150295691)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28283059658218295692)
,p_event_id=>wwv_flow_imp.id(28283058851641295691)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(725877973788256312)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ChkMatchToCreateUpdate'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v__exist NUMBER;',
'BEGIN',
'SELECT COUNT(*)',
'INTO v__exist',
'FROM users_role',
'WHERE userid = :P18_USERID',
'AND roleid = :P18_ROLEID',
'AND team_id = :P18_TEAM_ID;',
'',
'IF v__exist <= 0 THEN',
'NULL;',
'ELSE ',
'RAISE_APPLICATION_ERROR(-20007,''This user already play this role on this team'');',
'END IF;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>725877973788256312
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28283061740045295693)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(28283055865521295689)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Auth'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28283061740045295693
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28283062155910295693)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>28283062155910295693
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28283061342487295693)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(28283055865521295689)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Auth'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28283061342487295693
);
wwv_flow_imp.component_end;
end;
/
