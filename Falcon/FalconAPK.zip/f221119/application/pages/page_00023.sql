prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_name=>'Edit Team Leader'
,p_alias=>'EDIT-TEAM-LEADER'
,p_page_mode=>'MODAL'
,p_step_title=>'Edit Team Leader'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231008082937'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64944455032141547356)
,p_plug_name=>'Add New Team'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'TEAMS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64944458150393547359)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645481003320606385)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35458912228878129661)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(64944458150393547359)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35458912631952129661)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(64944458150393547359)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P23_TEAM_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35458913007263129661)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(64944458150393547359)
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P23_TEAM_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64944455872253547366)
,p_name=>'P23_TEAM_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(64944455032141547356)
,p_item_source_plug_id=>wwv_flow_imp.id(64944455032141547356)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Team Id'
,p_source=>'TEAM_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64944456699947547367)
,p_name=>'P23_TEAM_LEADER'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(64944455032141547356)
,p_item_source_plug_id=>wwv_flow_imp.id(64944455032141547356)
,p_prompt=>'Team Leader'
,p_source=>'TEAM_LEADER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'USERNAME(SIMPLE)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT full_name||'' (''||email||'' - ''||id_no||'')'' d, userid r',
'FROM user_tables',
'where status IN (''Y'',''N'')',
'order by 1 asc'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35458914869455129664)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35458912228878129661)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35458915316700129664)
,p_event_id=>wwv_flow_imp.id(35458914869455129664)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36299868496342607007)
,p_name=>'Rmv_Name'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35458912631952129661)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36299868504022607008)
,p_event_id=>wwv_flow_imp.id(36299868496342607007)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE teams',
'SET team_leader = Null',
'WHERE team_id = :P23_TEAM_ID;',
'END;'))
,p_attribute_02=>'P23_TEAM_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36299868659806607009)
,p_event_id=>wwv_flow_imp.id(36299868496342607007)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36299868784183607010)
,p_name=>'Upd'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35458913007263129661)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36299868808523607011)
,p_event_id=>wwv_flow_imp.id(36299868784183607010)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE teams',
'SET team_leader = :P23_TEAM_LEADER',
'WHERE team_id = :P23_TEAM_ID;',
'END;'))
,p_attribute_02=>'P23_TEAM_ID,P23_TEAM_LEADER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36299868911601607012)
,p_event_id=>wwv_flow_imp.id(36299868784183607010)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35458914025727129663)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (30) :=  NULL;',
'BEGIN',
'',
'    SELECT MAX (team_id)',
'      INTO NEW_PK',
'      FROM teams;',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ',
'    :P23_TEAM_ID := NEW_PK;',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>35458914025727129663
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35458911519247129660)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(64944455032141547356)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Add New Team'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>35458911519247129660
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35458914454274129663)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>35458914454274129663
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35458911186923129660)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(64944455032141547356)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Add New Team'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>35458911186923129660
);
wwv_flow_imp.component_end;
end;
/
