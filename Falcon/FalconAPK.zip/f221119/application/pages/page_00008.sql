prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'User Preview'
,p_alias=>'USER-PREVIEW'
,p_step_title=>'User Preview'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Footer {',
'    ',
'    display: none;',
'    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231102082245'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2380530486043787602)
,p_plug_name=>'All Application Users'
,p_icon_css_classes=>'fa-users'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645511538145606399)
,p_plug_display_sequence=>10
,p_menu_id=>wwv_flow_imp.id(27645441599237606364)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(27645619693166606450)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9798339502823679903)
,p_plug_name=>'Parameters'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(28282405379419732679)
,p_name=>'User Preview'
,p_template=>wwv_flow_imp.id(27645544873689606414)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  USERID,',
'       USERNAME,',
'       PASSCODE,',
'       STATUS,',
'       PROID,',
'       FULL_NAME,',
'       '''' edit,',
'       company, designation, cell, email, id_no identification_no,',
'       nvl((select listagg((select listagg(team_name,''| '') within group (order by team_name) from teams where team_members.team_id = teams.team_id),''| '')',
'       within group (order by team_id) ',
'       from team_members ',
'       where ',
'        ut.userid = team_members.userid),''No Team'')',
'       name_of_teams',
'  from USER_TABLES ut',
'  where  (',
'    (SELECT COUNT(userid) FROM TEAM_MEMBERS WHERE TEAM_ID = :P8_TEAM_ID) > 0 AND USERID IN (SELECT USERID FROM TEAM_MEMBERS WHERE TEAM_ID = :P8_TEAM_ID)',
') OR (',
'    (SELECT COUNT(userid) FROM TEAM_MEMBERS WHERE TEAM_ID = :P8_TEAM_ID) = 0 AND USERID IN (SELECT USERID FROM USER_TABLES)',
')',
'  order by full_name asc',
'',
'',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P8_TEAM_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28282405605423732778)
,p_query_column_id=>1
,p_column_alias=>'USERID'
,p_column_display_sequence=>0
,p_column_heading=>'Userid'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28282406025520732779)
,p_query_column_id=>2
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>50
,p_column_heading=>'Username'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28282406478449732779)
,p_query_column_id=>3
,p_column_alias=>'PASSCODE'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28282406823361732779)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>100
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Approved;Y,Not Approved;N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28282407274248732779)
,p_query_column_id=>5
,p_column_alias=>'PROID'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28282407618588732779)
,p_query_column_id=>6
,p_column_alias=>'FULL_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Full Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28280786972542655503)
,p_query_column_id=>7
,p_column_alias=>'EDIT'
,p_column_display_sequence=>10
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RR,7:P7_USERID:#USERID#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-edit"></span>'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28280788544214655519)
,p_query_column_id=>8
,p_column_alias=>'COMPANY'
,p_column_display_sequence=>70
,p_column_heading=>'Company'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28280788654335655520)
,p_query_column_id=>9
,p_column_alias=>'DESIGNATION'
,p_column_display_sequence=>60
,p_column_heading=>'Designation'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28280788786870655521)
,p_query_column_id=>10
,p_column_alias=>'CELL'
,p_column_display_sequence=>80
,p_column_heading=>'Cell'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(28280788845780655522)
,p_query_column_id=>11
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>90
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(75944659372141265703)
,p_query_column_id=>12
,p_column_alias=>'IDENTIFICATION_NO'
,p_column_display_sequence=>40
,p_column_heading=>'Identification No'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9798339974857679907)
,p_query_column_id=>13
,p_column_alias=>'NAME_OF_TEAMS'
,p_column_display_sequence=>130
,p_column_heading=>'Name Of Teams'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36686914139359930301)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_column=>8
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(28282405379419732679)
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9798339434503679902)
,p_name=>'P8_TEAM_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9798339502823679903)
,p_prompt=>'Team'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TEAM'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Select Team--'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36686914200188930302)
,p_name=>'P8_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(36686914139359930301)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28280787918504655513)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28280788021174655514)
,p_event_id=>wwv_flow_imp.id(28280787918504655513)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28282405379419732679)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9798339614919679904)
,p_name=>'WatchQ'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_TEAM_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9798339761582679905)
,p_event_id=>wwv_flow_imp.id(9798339614919679904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28282405379419732679)
);
wwv_flow_imp.component_end;
end;
/
