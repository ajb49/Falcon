prompt --application/pages/page_00039
begin
--   Manifest
--     PAGE: 00039
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>39
,p_name=>'Assigned'
,p_alias=>'ASSIGNED'
,p_page_mode=>'MODAL'
,p_step_title=>'Assigned'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(27645471561620606380)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231026083351'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4712822259293629911)
,p_plug_name=>'Wizard Progress'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_imp.id(4712817063779629905)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(27645613851171606447)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4712822387778629911)
,p_plug_name=>'Assigned'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4710161327248605413)
,p_plug_name=>'ASSIGNED'
,p_parent_plug_id=>wwv_flow_imp.id(4712822387778629911)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2867559446964304642)
,p_name=>'TEAM_MEMBERS_EXIST_TASK'
,p_region_name=>'chexist'
,p_parent_plug_id=>wwv_flow_imp.id(4710161327248605413)
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT (select full_name from user_tables ut where ut.userid = tm.userid and status = ''Y'')',
'||'' (''||(select email||'' ''||id_no from user_tables ut where ut.userid = tm.userid and status = ''Y'')||'')'' full_name ',
',userid,TEAM_ID',
',apex_item.checkbox(1,userid, p_checked_values => :BIND_USER_ID) checkbox',
'from team_members tm',
'where (team_id = :P39_TEAM_ID) ',
'and ',
'(userid not in (select userid ',
'                from user_tasks usk ',
'                --where team_id = :P39_TEAM_ID ',
'                where proid in (select n005 from apex_collections where collection_name = ''MYTASK''))) ',
'--(team_id = :P3_TEAM )',
'order by  2 asc, 2 nulls last'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P39_TEAM_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2867559641956304644)
,p_query_column_id=>1
,p_column_alias=>'FULL_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Team Member'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2867559775029304645)
,p_query_column_id=>2
,p_column_alias=>'USERID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2867560010434304648)
,p_query_column_id=>3
,p_column_alias=>'TEAM_ID'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2867559562968304643)
,p_query_column_id=>4
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" id="selectunselectall">'
,p_column_format=>'PCT_GRAPH:::'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4710161528319605415)
,p_name=>'TEAM_MEMBERS'
,p_region_name=>'chkbx'
,p_parent_plug_id=>wwv_flow_imp.id(4710161327248605413)
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT (select full_name from user_tables ut where ut.userid = tm.userid and status = ''Y'')',
'||'' (''||(select email||'' ''||id_no from user_tables ut where ut.userid = tm.userid and status = ''Y'')||'')'' full_name ',
',userid',
',apex_item.checkbox(2,userid, p_checked_values => :BIND_USER_ID) checkbox',
'from team_members tm',
'where (team_id = :P39_TEAM_ID) ',
'or (userid in (select userid from user_tasks usk where team_id = :P39_TEAM_ID)) ',
'--(team_id = :P3_TEAM )',
'order by  2 asc, 2 nulls last'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P39_TEAM_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4710161723540605417)
,p_query_column_id=>1
,p_column_alias=>'FULL_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Team Member'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4710161609715605416)
,p_query_column_id=>2
,p_column_alias=>'USERID'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4710162087932605420)
,p_query_column_id=>3
,p_column_alias=>'CHECKBOX'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" id="selectunselectall">'
,p_column_format=>'PCT_GRAPH:::'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4712822439054629911)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645481003320606385)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4712823985789629912)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4712822439054629911)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4712824073196629912)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(4712822439054629911)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4712824136465629912)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4712822439054629911)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645617343518606449)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(4712825831981629913)
,p_branch_action=>'f?p=&APP_ID.:38:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(4712824136465629912)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2867559050698304638)
,p_name=>'P39_EXISTANCE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4710161327248605413)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4710161453145605414)
,p_name=>'P39_TEAM_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4710161327248605413)
,p_item_default=>':BIND_TEAM_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Team'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TEAM'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4710163043680605430)
,p_name=>'P39_PROID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4710161327248605413)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4710163163982605431)
,p_name=>'P39_INS_BY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4710161327248605413)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4710163264479605432)
,p_name=>'P39_INS_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4710161327248605413)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4712824345015629912)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(4712823985789629912)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4712825177340629913)
,p_event_id=>wwv_flow_imp.id(4712824345015629912)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4710161856990605418)
,p_name=>'RFS'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P39_TEAM_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4710161933905605419)
,p_event_id=>wwv_flow_imp.id(4710161856990605418)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4710161528319605415)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6156955604024245828)
,p_event_id=>wwv_flow_imp.id(4710161856990605418)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2867559446964304642)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4710162143807605421)
,p_name=>'SELECTALL'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectunselectall'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#chkbx'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4710162242281605422)
,p_event_id=>wwv_flow_imp.id(4710162143807605421)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#chkbx #selectunselectall'' ).is('':checked'')){',
'$(''#chkbx input[type=checkbox][name=f02]'').prop(''checked'',true);',
'} else {',
'$(''#chkbx input[type=checkbox][name=f02]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2867560184234304649)
,p_name=>'SELECTALL_1'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectunselectall'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#chexist'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2867560290710304650)
,p_event_id=>wwv_flow_imp.id(2867560184234304649)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#chexist #selectunselectall'' ).is('':checked'')){',
'$(''#chexist input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'$(''#chexist input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2867559198177304639)
,p_name=>'OpenMembers'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P39_EXISTANCE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2867559256375304640)
,p_event_id=>wwv_flow_imp.id(2867559198177304639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4710161528319605415)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P39_EXISTANCE'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2867559886954304646)
,p_event_id=>wwv_flow_imp.id(2867559198177304639)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2867559446964304642)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P39_EXISTANCE'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2867559326798304641)
,p_event_id=>wwv_flow_imp.id(2867559198177304639)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4710161528319605415)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P39_EXISTANCE'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2867559961735304647)
,p_event_id=>wwv_flow_imp.id(2867559198177304639)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2867559446964304642)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P39_EXISTANCE'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4710163320943605433)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DefaultValue'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P39_INS_BY := :BIND_USER_ID;',
':P39_INS_DATE := CURRENT_TIMESTAMP;',
'',
'SELECT c005',
'INTO :P39_EXISTANCE',
'FROM apex_collections',
'WHERE collection_name = ''MYTASK''',
'FETCH FIRST 1 ROW ONLY;',
'',
'EXCEPTION ',
'WHEN NO_DATA_FOUND THEN',
':P39_EXISTANCE := NULL;',
':P39_INS_BY := :BIND_USER_ID;',
':P39_INS_DATE := CURRENT_TIMESTAMP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>4710163320943605433
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4710163456631605434)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'InsertCollection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P39_EXISTANCE = ''N'' THEN',
'',
'        IF NOT apex_collection.collection_exists(''MYASSIGN'') THEN',
'        apex_collection.create_collection(''MYASSIGN'');',
'        ELSE',
'        apex_collection.truncate_collection(''MYASSIGN'');',
'        END IF;',
'                If APEX_APPLICATION.G_F02.count <= 0 THEN',
'                RAISE_APPLICATION_ERROR(-20001,''Please select at least one member'');',
'                ELSIF APEX_APPLICATION.G_F02.count > 0 THEN',
'                NULL;',
'                END IF;',
'',
'            FOR i in 1..APEX_APPLICATION.G_F02.count',
'            LOOP',
'',
'                    apex_collection.add_member(',
'                        p_collection_name => ''MYASSIGN'',',
'                        p_n001 => to_number(APEX_APPLICATION.G_F02(i)),',
'                        p_n002 => :P39_TEAM_ID,',
'                        p_n003 => :P39_INS_BY,',
'                        p_d001 => :P39_INS_DATE',
'                    );',
'            END LOOP;',
'ELSIF :P39_EXISTANCE = ''Y'' THEN',
'     IF NOT apex_collection.collection_exists(''MYASSIGN'') THEN',
'        apex_collection.create_collection(''MYASSIGN'');',
'        ELSE',
'        apex_collection.truncate_collection(''MYASSIGN'');',
'        END IF;',
'                If APEX_APPLICATION.G_F01.count <= 0 THEN',
'                RAISE_APPLICATION_ERROR(-20001,''Please select at least one member'');',
'                ELSIF APEX_APPLICATION.G_F01.count > 0 THEN',
'                NULL;',
'                END IF;',
'',
'            FOR i in 1..APEX_APPLICATION.G_F01.count',
'            LOOP',
'',
'                    apex_collection.add_member(',
'                        p_collection_name => ''MYASSIGN'',',
'                        p_n001 => to_number(APEX_APPLICATION.G_F01(i)),',
'                        p_n002 => :P39_TEAM_ID,',
'                        p_n003 => :P39_INS_BY,',
'                        p_d001 => :P39_INS_DATE',
'                    );',
'            END LOOP;',
'',
'END IF;',
'END;',
'',
'---------------------------------------------------------------------',
'---------------------------------------------------------------------',
'DECLARE',
'v__exist INTEGER;',
'BEGIN',
'SELECT count(c005)',
'INTO v__exist',
'FROM apex_collections',
'WHERE collection_name = ''MYTASK''',
'AND c005 = ''N'';',
'IF v__exist > 0 THEN',
'--for single row data',
'        DECLARE',
'            NEW_PK            VARCHAR2 (30) :=  NULL;',
'            v__task_name    project_details.task_name%type;',
'            v__project_id   project_details.project_id%type;',
'            v__start_from   project_details.start_from%type;',
'            v__end_to       project_details.end_to%type;',
'            v__status       project_details.status%type;',
'            v__ins_by       project_details.ins_by%type;',
'            v__ins_date     project_details.ins_date%type;',
'            v__sts_by       project_details.sts_by%type;',
'            v__team_id      project_details.team_id%type;',
'            v__attachfile   project_attachments.attachement_file%type;',
'            v__mimetype     project_attachments.mimetype%type;',
'            v__filename     project_attachments.filename%type;',
'            v__createddate  project_attachments.createddate%type;',
'',
'        BEGIN',
'            SELECT MAX (PROID)',
'              INTO NEW_PK',
'              FROM PROJECT_DETAILS;  ',
'            IF NEW_PK IS NULL THEN',
'                NEW_PK := 1000;',
'            ELSE',
'                NEW_PK := NEW_PK + 1;',
'            END IF;',
'        SELECT c001, n001, d001, d002, c002, n002, d004, n003, n004',
'                ,blob001, c003, c004, d003',
'        INTO v__task_name, v__project_id, v__start_from, v__end_to, v__status, v__ins_by, v__ins_date, v__sts_by, v__team_id',
'              ,v__attachfile, v__mimetype, v__filename, v__createddate',
'        FROM apex_collections',
'        WHERE collection_name = ''MYTASK'';',
'        INSERT INTO project_details (proid, task_name, start_from, end_to, status, project_id, ins_by, ins_date, sts_by, team_id)',
'        VALUES (NEW_PK,v__task_name,v__start_from,v__end_to,v__status,v__project_id,v__ins_by,CURRENT_TIMESTAMP,v__sts_by,v__team_id);',
'            IF v__status = ''1'' THEN',
'            UPDATE project_details',
'            SET upd_done = CURRENT_TIMESTAMP',
'            WHERE proid = NEW_PK;',
'            ELSIF v__status != ''1'' THEN',
'            NULL;',
'            END IF;',
'        IF v__filename IS NULL THEN',
'        NULL;',
'        ELSIF v__filename IS NOT NULL THEN',
'        INSERT INTO project_attachments (proid, attachement_file, filename, mimetype, createddate,name_file)',
'        VALUES (NEW_PK,v__attachfile,v__filename,v__mimetype,v__createddate,v__filename);',
'        END IF;',
'',
'            FOR j IN (SELECT  n001, n003, d001, n002',
'                        FROM apex_collections',
'                        WHERE collection_name = ''MYASSIGN'') LOOP',
'            INSERT INTO user_tasks (userid, proid, ins_by, ins_date, team_id)',
'            VALUES (j.n001,NEW_PK,j.n003,CURRENT_TIMESTAMP,j.n002);',
'            END LOOP;',
'        EXCEPTION',
'         WHEN OTHERS THEN',
'           HTP.P(SQLERRM);',
'        END;',
'ELSIF v__exist <= 0 THEN',
'',
'FOR i IN (SELECT n005 FROM apex_collections WHERE collection_name = ''MYTASK'') LOOP',
'        FOR j IN (SELECT  n001, n003, d001, n002',
'                                FROM apex_collections',
'                                WHERE collection_name = ''MYASSIGN'') LOOP',
'                    INSERT INTO user_tasks (userid, proid, ins_by, ins_date, team_id)',
'                    VALUES (j.n001,i.n005,j.n003,CURRENT_TIMESTAMP,j.n002);',
'        END LOOP;',
'END LOOP;',
'END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>4710163456631605434
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4712826670282629913)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>4712826670282629913
);
wwv_flow_imp.component_end;
end;
/
