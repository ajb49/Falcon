prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Main Project'
,p_alias=>'MAIN-PROJECT'
,p_step_title=>'Main Project'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Footer {',
'    ',
'    display: none;',
'    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231018204711'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(27878520402490842313)
,p_name=>'Main Project'
,p_template=>wwv_flow_imp.id(27645544873689606414)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--accent7:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROJECT_ID,',
'       PROJECT_NAME,',
'       PROJECT_DESCRIPTION,',
'       STATUS,',
'       CHECK_IN,',
'       CHECK_OUT,',
'       COMMENTS,',
'       '''' edit,',
'       time_spell(check_out-sysdate) remained,',
'       case',
unistr('when status=''N'' and comments=''Y'' then ''\D83D\DE42'''),
unistr('when status=''N'' and comments=''N'' then ''\D83D\DE1F'''),
unistr('when status=''Y'' and comments=''N'' then ''\D83D\DE10'''),
unistr('when status=''Y'' and comments=''Y'' then ''\D83D\DE00'''),
'else null end ',
'expression,',
''''' preview',
'',
'  from PROJECTS',
'  WHERE (TEAM_ID = :BIND_TEAM_ID OR TEAM_ID IS NULL)',
'  and',
'  (root_id = :P10_MAIN_PROJECT or :P10_MAIN_PROJECT is null)',
'  and',
'  status = :P10_STATUS',
'  order by status desc, CHECK_IN asc, STATUS DESC;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P10_MAIN_PROJECT,P10_STATUS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_num_rows=>6
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no project found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27878521547324842386)
,p_query_column_id=>1
,p_column_alias=>'PROJECT_ID'
,p_column_display_sequence=>0
,p_column_heading=>'Project ID'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27878521941302842387)
,p_query_column_id=>2
,p_column_alias=>'PROJECT_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Project Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27878522385149842387)
,p_query_column_id=>3
,p_column_alias=>'PROJECT_DESCRIPTION'
,p_column_display_sequence=>40
,p_column_heading=>'Project Description'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_report_column_width=>500
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27878522753368842387)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>50
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Running;Y,Stopped;N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27878523127394842387)
,p_query_column_id=>5
,p_column_alias=>'CHECK_IN'
,p_column_display_sequence=>60
,p_column_heading=>'Check In'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-RR'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27878523556482842388)
,p_query_column_id=>6
,p_column_alias=>'CHECK_OUT'
,p_column_display_sequence=>70
,p_column_heading=>'Check Out'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-RR'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27875487688783226110)
,p_query_column_id=>7
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>80
,p_column_heading=>'Comments'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Completed;Y,Incompleted;N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27875487263961226106)
,p_query_column_id=>8
,p_column_alias=>'EDIT'
,p_column_display_sequence=>20
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RR,10:P2_PROJECT_ID,P2_CHECK_OUT:#PROJECT_ID#,#CHECK_OUT#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-edit"></span>'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27875488227547226116)
,p_query_column_id=>9
,p_column_alias=>'REMAINED'
,p_column_display_sequence=>90
,p_column_heading=>'Remained'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(30534588679691991636)
,p_query_column_id=>10
,p_column_alias=>'EXPRESSION'
,p_column_display_sequence=>10
,p_column_heading=>'&nbsp'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43408026937821002523)
,p_query_column_id=>11
,p_column_alias=>'PREVIEW'
,p_column_display_sequence=>100
,p_column_heading=>'Quick Preview'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::P29_PROJECT_ID:#PROJECT_ID#'
,p_column_linktext=>'<span class="fa fa-info-circle" aria-hidden="true"></span>'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28720455233056109021)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27878520402490842313)
,p_button_name=>'Refresh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--warning:t-Button--simple:t-Button--hoverIconSpin'
,p_button_template_id=>wwv_flow_imp.id(27645617343518606449)
,p_button_image_alt=>'Refresh'
,p_button_position=>'EDIT'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30534588323475991633)
,p_name=>'P10_MAIN_PROJECT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27878520402490842313)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_prompt=>'Head of Project'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROJECT_NAME||'': ''||TO_CHAR(CHECK_OUT,''DD-MON'') PROJECT_NAME, PROJECT_ID ',
'from PROJECTS ',
'where (TEAM_ID = :BIND_TEAM_ID OR TEAM_ID IS NULL) ',
'AND STATUS IN (''Y'') ',
'AND project_id IN (SELECT DISTINCT root_id ',
'                    FROM projects);'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Select Parent Project--'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35623479363498290508)
,p_name=>'P10_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27878520402490842313)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'Y'
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Running;Y,Stopped;N'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27875487360969226107)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27875487448809226108)
,p_event_id=>wwv_flow_imp.id(27875487360969226107)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(27878520402490842313)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28720453541799109004)
,p_event_id=>wwv_flow_imp.id(27875487360969226107)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_BIND_PROJECT_DAYS_LEFT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30534588411610991634)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_MAIN_PROJECT,P10_STATUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30534588535693991635)
,p_event_id=>wwv_flow_imp.id(30534588411610991634)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(27878520402490842313)
);
wwv_flow_imp.component_end;
end;
/
