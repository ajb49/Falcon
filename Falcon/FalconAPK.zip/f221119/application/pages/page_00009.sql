prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Job Progress'
,p_alias=>'JOB-PROGRESS'
,p_step_title=>'Job Progress'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Footer {',
'    ',
'    display: none;',
'    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231023151503'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28720453703956109006)
,p_plug_name=>'LEFT'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30534586572535991615)
,p_plug_name=>'RIGHT'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37180416334167355907)
,p_plug_name=>'BOTTOM'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>30
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37180416474388355908)
,p_plug_name=>'Typical Day'
,p_parent_plug_id=>wwv_flow_imp.id(37180416334167355907)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(27645544873689606414)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'SELF_IMPROVEMENTS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37180417377061355917)
,p_plug_name=>'Button'
,p_parent_plug_id=>wwv_flow_imp.id(37180416334167355907)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(27645544873689606414)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2867555947070304607)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(37180417377061355917)
,p_button_name=>'Call_Modal'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Call Modal'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28720454077612109009)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(28720453703956109006)
,p_button_name=>'ADD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30534587127392991621)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(30534586572535991615)
,p_button_name=>'Update'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Update'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37180417530392355919)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(37180417377061355917)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Save'
,p_button_position=>'CHANGE'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37180417763542355921)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(37180417377061355917)
,p_button_name=>'apply_change'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Apply Change'
,p_button_position=>'CHANGE'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37180417475565355918)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(37180417377061355917)
,p_button_name=>'Delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28720453883044109007)
,p_name=>'P9_ACTION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(28720453703956109006)
,p_prompt=>'Job Application Numbers'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28720453971126109008)
,p_name=>'P9_PROBABILITY_DAYS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(28720453703956109006)
,p_prompt=>'Progressive Day'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30534586638420991616)
,p_name=>'P9_GET_JOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30534586572535991615)
,p_prompt=>'Did you find any job?'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Yes;Y,No;N'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36668880299927368301)
,p_name=>'P9_TODAYS_ENTRY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(28720453703956109006)
,p_prompt=>'Todays Entry'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37180416662960355910)
,p_name=>'P9_SI'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_source_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_source=>'SI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37180416796952355911)
,p_name=>'P9_SLEEP_TIME'
,p_source_data_type=>'TIMESTAMP'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_source_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_default=>'sysdate - 1'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Sleep Time'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'SLEEP_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37180416869867355912)
,p_name=>'P9_AWAKE_TIME'
,p_source_data_type=>'TIMESTAMP'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_source_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Awake Time'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'AWAKE_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37180416969768355913)
,p_name=>'P9_BURN_CAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_source_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_prompt=>'Burn Calory'
,p_source=>'BURN_CAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37180417060150355914)
,p_name=>'P9_STRESS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_source_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_default=>'Y'
,p_prompt=>'Stress'
,p_source=>'STRESS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Yes;Y,No;N'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37180417179015355915)
,p_name=>'P9_DRINK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_source_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_prompt=>'Glass of Drinking Water'
,p_source=>'DRINK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37180417212654355916)
,p_name=>'P9_ADDICTION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_source_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_default=>'Y'
,p_prompt=>'Addiction'
,p_source=>'ADDICTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Yes;Y,No;N'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37180418040792355924)
,p_name=>'P9_EVERYDAY'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_source_plug_id=>wwv_flow_imp.id(37180416474388355908)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Everyday'
,p_source=>'EVERYDAY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28720454124068109010)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28720454077612109009)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28720454284716109011)
,p_event_id=>wwv_flow_imp.id(28720454124068109010)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'project_progress(:P9_ACTION,:P9_PROBABILITY_DAYS);',
'IF :P9_PROBABILITY_DAYS <= 0 THEN',
':P9_PROBABILITY_DAYS := ''LOST ''||ABS(:P9_PROBABILITY_DAYS)||'' Days'';',
'ELSE',
':P9_PROBABILITY_DAYS := ''SAVE ''||:P9_PROBABILITY_DAYS||'' Days'';',
'END IF;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'NULL;',
'END;',
''))
,p_attribute_02=>'P9_ACTION,P9_PROBABILITY_DAYS'
,p_attribute_03=>'P9_PROBABILITY_DAYS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28720454313477109012)
,p_event_id=>wwv_flow_imp.id(28720454124068109010)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_PROBABILITY_DAYS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28720455005486109019)
,p_event_id=>wwv_flow_imp.id(28720454124068109010)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_ACTION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28720454872990109017)
,p_name=>'New_1'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28720454983773109018)
,p_event_id=>wwv_flow_imp.id(28720454872990109017)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.ITEMS.WITH.BUTTONS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(28720454077612109009)
,p_attribute_01=>'P9_ACTION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30534587241480991622)
,p_name=>'New_2'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30534587325940991623)
,p_event_id=>wwv_flow_imp.id(30534587241480991622)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.ITEMS.WITH.BUTTONS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(30534587127392991621)
,p_attribute_01=>'P9_GET_JOB'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30534587412033991624)
,p_name=>'New_3'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30534587127392991621)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30534587523423991625)
,p_event_id=>wwv_flow_imp.id(30534587412033991624)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE progress_tracks',
'SET get_job = :P9_GET_JOB',
'where rowid = ''ALsb7EAABAACtGlAAA'';',
'COMMIT;',
'END;'))
,p_attribute_02=>'P9_GET_JOB'
,p_attribute_03=>'P9_GET_JOB'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30534587917748991629)
,p_event_id=>wwv_flow_imp.id(30534587412033991624)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_GET_JOB'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P9_GET_JOB'
,p_attribute_07=>'P9_GET_JOB'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30534587787581991627)
,p_name=>'New_4'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30534587867788991628)
,p_event_id=>wwv_flow_imp.id(30534587787581991627)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'SELECT get_job',
'INTO :P9_GET_JOB',
'FROM progress_tracks',
'FETCH FIRST 1 ROW ONLY;',
'END;'))
,p_attribute_03=>'P9_GET_JOB'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36668880378021368302)
,p_name=>'New_5'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_TODAYS_ENTRY'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36668880447590368303)
,p_event_id=>wwv_flow_imp.id(36668880378021368302)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_c INTEGER;',
'begin',
'select count(*) ',
'INTO v_c',
'from progress ',
'where to_char(today,''mm/dd/yyyy'') = to_char(sysdate,''mm/dd/yyyy'');',
'IF v_c > 0 then',
':P9_TODAYS_ENTRY := ''Applied'';',
'ELSIF v_c <=0 then',
':P9_TODAYS_ENTRY := ''No Applied Today'';',
'END IF;',
'',
'end;'))
,p_attribute_02=>'P9_TODAYS_ENTRY'
,p_attribute_03=>'P9_TODAYS_ENTRY'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37180417821534355922)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (30) :=  NULL;',
'BEGIN',
'',
'    SELECT MAX (si)',
'      INTO NEW_PK',
'      FROM self_improvements;',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ',
'    :P9_SI := NEW_PK;',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37180417530392355919)
,p_internal_uid=>37180417821534355922
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37180417989074355923)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(37180416474388355908)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'New_3'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>37180417989074355923
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28720454473368109013)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'New'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_internal_uid=>28720454473368109013
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28720454579683109014)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'SELECT probability',
'into :P9_PROBABILITY_DAYS',
'from progress',
'order by pk desc',
'fetch first 1 row only;',
'-- BEGIN',
'-- SELECT get_job',
'-- INTO :P9_GET_JOB',
'-- FROM progress_tracks',
'-- FETCH FIRST 1 ROW ONLY;',
'-- END;',
'',
'if :P9_PROBABILITY_DAYS <= 0 then',
':P9_PROBABILITY_DAYS := ''LOST ''||ABS(:P9_PROBABILITY_DAYS)||'' Days'';',
'else',
':P9_PROBABILITY_DAYS := ''SAVE ''||:P9_PROBABILITY_DAYS||'' Days'';',
'end if;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'NULL;',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>28720454579683109014
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37180416510803355909)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(37180416474388355908)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Job Progress'
,p_internal_uid=>37180416510803355909
);
wwv_flow_imp.component_end;
end;
/
