prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Login Page'
,p_alias=>'LOGIN'
,p_step_title=>'Falcon - Log In'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-PageBody--login form#wwvFlowForm{',
'    background:url(#APP_FILES#wallpaperflare.com_wallpaper.jpg);',
'    background-repeat:no-repeat;',
'    background-Size:cover;',
'}'))
,p_step_template=>wwv_flow_imp.id(27645452990829606371)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231103073728'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27645730460419606518)
,p_plug_name=>'Falcon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645539628745606411)
,p_plug_display_sequence=>10
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27645732176024606520)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(27645730460419606518)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sign In'
,p_button_position=>'NEXT'
,p_button_alignment=>'LEFT'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27875488559892226119)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(27645730460419606518)
,p_button_name=>'Signup'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Registration'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:12::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27645730926951606519)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27645730460419606518)
,p_prompt=>'Username'
,p_placeholder=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="username"'
,p_field_template=>wwv_flow_imp.id(27645615235042606448)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27645731377118606520)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27645730460419606518)
,p_prompt=>'Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="current-password"'
,p_field_template=>wwv_flow_imp.id(27645615235042606448)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27645731711097606520)
,p_name=>'P9999_REMEMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(27645730460419606518)
,p_prompt=>'Remember username'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'apex_authentication.persistent_cookies_enabled'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(27645615235042606448)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29494189773445735518)
,p_name=>'P9999_TEAM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(27645730460419606518)
,p_prompt=>'Team'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT (select team_name from teams t where t.team_id = l.team_id) team_name, team_id',
'from team_members l',
'where userid = (select userid from user_tables where lower(username) = lower(:P9999_USERNAME));'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P9999_USERNAME'
,p_ajax_items_to_submit=>'P9999_USERNAME'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9798339338683679901)
,p_validation_name=>'ChkAllAreInTeam'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v__user INTEGER;',
'BEGIN',
'select count(*) -- 0 means every active user is in any team',
'into v__user',
'from user_Tables ',
'where status = ''Y'' ',
'and userid not in (',
'    select distinct userid ',
'    from team_members) ;',
'IF v__user > 0 THEN',
'RETURN TRUE;',
'ELSIF v__user <= 0 THEN',
'    IF :P9999_TEAM IS NULL THEN',
'    RETURN FALSE;',
'    ELSIF :P9999_TEAM IS NOT NULL THEN',
'    RETURN TRUE;',
'    END IF;',
'END IF;',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Please Select Your Team'
,p_associated_item=>wwv_flow_imp.id(29494189773445735518)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(725877716077256310)
,p_name=>'ShowTeam'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9999_USERNAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(725877877295256311)
,p_event_id=>wwv_flow_imp.id(725877716077256310)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'select distinct team_id',
'into :P9999_TEAM',
'from team_members',
'where userid = (select userid from user_tables where lower(username) = lower(:P9999_USERNAME))',
'order by team_id',
'fetch first 1 row only;',
'exception',
'when no_data_found then',
'null;',
'when others then',
'null;',
'end;'))
,p_attribute_02=>'P9999_USERNAME'
,p_attribute_03=>'P9999_TEAM'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27645734334349606522)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27645734334349606522
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(27645734827670606522)
,p_page_process_id=>wwv_flow_imp.id(27645734334349606522)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'lower( :P9999_USERNAME )'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(27645735372026606522)
,p_page_process_id=>wwv_flow_imp.id(27645734334349606522)
,p_page_id=>9999
,p_name=>'p_consent'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_REMEMBER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27875488388410226117)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Login'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.login(',
'    p_username => :P9999_USERNAME,',
'    p_password => encrypto(:P9999_PASSWORD));',
'',
'----------------------login with custom authentication ways    ',
'begin',
'select userid into :BIND_USER_ID ',
'from user_tables ',
'where upper(username) = upper(:P9999_USERNAME); --identify user that canbe display into all pages',
'',
'select roleid into :BIND_USER_ROLE ',
'from users_role ',
'where userid = (select userid ',
'                from user_tables ',
'                where upper(username) = upper(:P9999_USERNAME) ',
'                and passcode = encrypto(:P9999_PASSWORD))',
'  and (team_id = :P9999_TEAM or :P9999_TEAM is null)',
'  order by roleid asc',
'  fetch first 1 row only; ',
'--identify roles of user',
'---------------------put remained days of project',
'begin',
'declare',
'v___remained number;',
'BEGIN',
'SELECT nvl(COUNT(*),0)',
'into v___remained',
'FROM PROJECTS',
'WHERE CHECK_OUT - SYSDATE <= 7',
'AND COMMENTS = ''N''',
'AND STATUS = ''Y'';',
'',
'if v___remained > 0 then',
'SELECT COUNT(*) IF_EXIST',
'INTO :BIND_PROJECT_DAYS_LEFT',
'FROM PROJECTS',
'WHERE (CHECK_OUT - SYSDATE <= 7) and (CHECK_OUT - SYSDATE >0)',
'AND COMMENTS = ''N''',
'AND STATUS = ''Y'';',
'else null;',
'end if;',
'END;',
'end;',
'',
':BIND_TEAM_ID := :P9999_TEAM;',
'--------------GET TEAM NAME',
'begin',
'SELECT INITCAP(team_name)',
'INTO :BIND_TEAM_NAME',
'FROM teams',
'WHERE team_id = :P9999_TEAM;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':BIND_TEAM_NAME := ''Falcon'';',
'end;',
'',
'SELECT TEAM_LEADER',
'INTO :BIND_TEAM_LEADER',
'FROM TEAMS',
'WHERE TEAM_ID = :P9999_TEAM;',
'',
'select count(*)',
'INTO :BIND_UNAPPROVAL_TASK',
'from PROJECT_DETAILS i',
'  where status not in (''1'',''3'',''4'',''0'',''2'')',
'  and proid in ((select proid from user_tasks where team_id IN :BIND_TEAM_ID));',
'',
'select count((select userid from user_tables ut where status = ''Y'' and ut.userid = tm.userid))',
'INTO :BIND_TEAM_MEMBER',
'from team_members tm',
'WHERE team_id = :P9999_TEAM;',
'',
'select count(*)',
'into :BIND_TO_DO',
'from PROJECT_DETAILS i',
'where status not in (''1'',''3'',''4'',''5'')',
'and proid in ((select proid from user_tasks where userid IN :BIND_USER_ID));',
'',
'select count(*)',
'into :BIND_HALT',
'from PROJECT_DETAILS i',
'where status in (''3'')',
'and proid in ((select proid from user_tasks where userid IN :BIND_USER_ID));',
'',
'exception',
'when no_data_found then',
'select userid into :BIND_USER_ID ',
'from user_tables ',
'where upper(username) = upper(:P9999_USERNAME); --identify user that can be displayed into all pages',
'when others then',
':BIND_USER_ROLE := 999;   --it works after put 999',
'select roleid into :BIND_USER_ROLE ',
'from users_role ',
'where userid = (select userid from user_tables where upper(username) = upper(:P9999_USERNAME) and passcode = :P9999_PASSWORD);',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27875488388410226117
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27645736289360606523)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Page(s) Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27645736289360606523
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27645735876869606522)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>27645735876869606522
);
wwv_flow_imp.component_end;
end;
/
