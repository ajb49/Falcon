prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>29
,p_name=>'Project Quick View'
,p_alias=>'PROJECT-QUICK-VIEW'
,p_page_mode=>'MODAL'
,p_step_title=>'Project Quick View'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1500'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231008090037'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(43408025749582002511)
,p_name=>'Report'
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select '''' changes, STATUS, '''' deleted, project_id, task_name, to_char(start_from,''dd/mon/yyyy'') start_date, to_char(end_to,''dd/mon/yyyy'') deadline, to_char(forecast,''dd/mon/yyyy'') submit_date, ',
'person involved_persons, pd.proid, '''' attachment  ',
',(select LISTAGG((select full_name from user_tables utb where utb.userid=ut.userid),'', '')',
' WITHIN GROUP (ORDER BY USERID) from user_tasks ut where ut.proid=pd.proid) Assigned_to',
',case when total_day >= 0 then to_char(total_day,''999990'')||''/''||to_char(round(end_to - start_from) + 1,''999990'')',
'when total_day < 0 then ''Done before Start''',
'else ',
'(case when status = 0 then ',
'        (case when to_date(sysdate,''mm/dd/yyyy'') - to_date(start_from,''mm/dd/yyyy'') >= 0 then to_char((to_date(sysdate,''mm/dd/yyyy'') - (to_date(start_from,''mm/dd/yyyy''))) + 1,''999990'')||''/''||to_char(round(end_to - start_from) + 1,''999990'')',
'        when to_date(sysdate,''mm/dd/yyyy'') - to_date(start_from,''mm/dd/yyyy'') < 0 then ''Upcoming''',
'        else null end)',
'when status = 2 then ''Additional +''||to_char((to_date(sysdate,''mm/dd/yyyy'') - (to_date(end_to,''mm/dd/yyyy'')) + 1),''999990'')||''/''||to_char(round(end_to - start_from) + 1,''999990'')',
'when status = 3 then ''Waiting''',
'when status = 4 then ''X'' else null end)',
' end "Total_Taken_Days"',
'',
'',
'from project_details pd, user_tasks ut',
',(select (to_date(to_char(upd_done,''mm/dd/yyyy'')) - to_date(start_from,''mm/dd/yyyy'') +1) total_day, proid from project_details) pv',
'where project_id = :P29_PROJECT_ID',
'and (status = :P29_STATUS or :P29_STATUS is null)',
'and ut.proid=pd.proid',
'and pd.proid=pv.proid',
'and (ut.userid = :P29_ASSIGNED_TO or :P29_ASSIGNED_TO is null)',
'GROUP BY ''Change'', STATUS, ''Delete'',project_id, task_name, to_char(start_from,''dd/mon/yyyy'') , to_char(end_to,''dd/mon/yyyy'') , to_char(forecast,''dd/mon/yyyy'') , ',
'person, pd.proid, ''attachment''',
',case when total_day >= 0 then to_char(total_day,''999990'')||''/''||to_char(round(end_to - start_from) + 1,''999990'')',
'when total_day < 0 then ''Done before Start''',
'else ',
'(case when status = 0 then ',
'        (case when to_date(sysdate,''mm/dd/yyyy'') - to_date(start_from,''mm/dd/yyyy'') >= 0 then to_char((to_date(sysdate,''mm/dd/yyyy'') - (to_date(start_from,''mm/dd/yyyy''))) + 1,''999990'')||''/''||to_char(round(end_to - start_from) + 1,''999990'')',
'        when to_date(sysdate,''mm/dd/yyyy'') - to_date(start_from,''mm/dd/yyyy'') < 0 then ''Upcoming''',
'        else null end)',
'when status = 2 then ''Additional +''||to_char((to_date(sysdate,''mm/dd/yyyy'') - (to_date(end_to,''mm/dd/yyyy'')) + 1),''999990'')||''/''||to_char(round(end_to - start_from) + 1,''999990'')',
'when status = 3 then ''Waiting''',
'when status = 4 then ''X'' else null end)',
' end ',
'order by pd.proid desc;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P29_STATUS,P29_PROJECT_ID,P29_ASSIGNED_TO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46905215414106151503)
,p_query_column_id=>1
,p_column_alias=>'CHANGES'
,p_column_display_sequence=>10
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:CR,31:P31_PROID,P31_PROJECT_ID,P31_STATUS:#PROID#,#PROJECT_ID#,#STATUS#'
,p_column_linktext=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'FUNCTION_BODY'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE IN (''1000'') THEN',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;',
'',
'END;'))
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46905215341232151502)
,p_query_column_id=>2
,p_column_alias=>'STATUS'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(45525624362570055437)
,p_query_column_id=>3
,p_column_alias=>'DELETED'
,p_column_display_sequence=>110
,p_column_heading=>'Remove'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:CR,30:P30_PROID,P30_PROJECT_ID:#PROID#,#PROJECT_ID##USERID#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-trash-o fam-star fam-is-danger"></span>'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'FUNCTION_BODY'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE IN (''1000'') THEN',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;',
'',
'END;'))
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(45525624435516055438)
,p_query_column_id=>4
,p_column_alias=>'PROJECT_ID'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43408025891955002512)
,p_query_column_id=>5
,p_column_alias=>'TASK_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Task Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43408025907865002513)
,p_query_column_id=>6
,p_column_alias=>'START_DATE'
,p_column_display_sequence=>40
,p_column_heading=>'Start Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43408026034767002514)
,p_query_column_id=>7
,p_column_alias=>'DEADLINE'
,p_column_display_sequence=>50
,p_column_heading=>'Deadline'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43408026112648002515)
,p_query_column_id=>8
,p_column_alias=>'SUBMIT_DATE'
,p_column_display_sequence=>60
,p_column_heading=>'Submit Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43408026234842002516)
,p_query_column_id=>9
,p_column_alias=>'INVOLVED_PERSONS'
,p_column_display_sequence=>70
,p_column_heading=>'Involved Persons'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::P4_PROID:#PROID#'
,p_column_linktext=>'#INVOLVED_PERSONS#'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43408026329643002517)
,p_query_column_id=>10
,p_column_alias=>'PROID'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43408026415580002518)
,p_query_column_id=>11
,p_column_alias=>'ATTACHMENT'
,p_column_display_sequence=>100
,p_column_heading=>'Attachment'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::P17_PROID:#PROID#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-paperclip"></span>'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(45525622999259055423)
,p_query_column_id=>12
,p_column_alias=>'ASSIGNED_TO'
,p_column_display_sequence=>30
,p_column_heading=>'Assigned To'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(45525623056352055424)
,p_query_column_id=>13
,p_column_alias=>'Total_Taken_Days'
,p_column_display_sequence=>90
,p_column_heading=>'Total Taken Days'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43408026646733002520)
,p_plug_name=>'ItemRegion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>40
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43408027249394002526)
,p_plug_name=>'ToSearch'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(43408025749582002511)
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43408026557847002519)
,p_name=>'P29_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(43408026646733002520)
,p_item_default=>'1'
,p_prompt=>'Project Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PROJECT STATUS'
,p_lov=>'.'||wwv_flow_imp.id(27651661124332706306)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43408027127318002525)
,p_name=>'P29_PROJECT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(43408026646733002520)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43408027341551002527)
,p_name=>'P29_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(43408027249394002526)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45525622850691055422)
,p_name=>'P29_ASSIGNED_TO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(43408026646733002520)
,p_prompt=>'Assigned To'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'USER_TABLES.USERNAME'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- SELECT full_name||'' (''||email||'')'' d, userid r',
'-- FROM user_tables',
'-- where status = ''Y''',
'-- order by 1 asc',
'',
'select distinct userid r, (select full_name||'' (''||email||'' - ''||id_no||'')'' d from user_tables ut where ut.userid = tm.userid and status = ''Y'') full_name ',
'from team_members tm',
'where team_id = :BIND_TEAM_ID',
'order by 2 asc, 2 nulls last;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43408026793601002521)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P29_STATUS,P29_PROJECT_ID,P29_ASSIGNED_TO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43408026852143002522)
,p_event_id=>wwv_flow_imp.id(43408026793601002521)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43408025749582002511)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45525625196412055445)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45525625245253055446)
,p_event_id=>wwv_flow_imp.id(45525625196412055445)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43408025749582002511)
);
wwv_flow_imp.component_end;
end;
/
