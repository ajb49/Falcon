prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Sign Up'
,p_alias=>'SIGN-UP'
,p_page_mode=>'MODAL'
,p_step_title=>'Sign Up'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231015215751'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28059989294643771843)
,p_plug_name=>'Sign Up'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USERID,',
'       USERNAME,',
'       PASSCODE,',
'       STATUS,',
'       PROID,',
'       FULL_NAME,',
'       DESIGNATION,',
'       COMPANY,',
'       EMAIL,',
'       CELL,',
'       ID_NO',
'  from USER_TABLES'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28059992325844771846)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645481003320606385)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28059992755657771847)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28059992325844771846)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28059994188223771848)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(28059992325844771846)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Deactivate Account'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P12_USERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28059994591728771848)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(28059992325844771846)
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P12_USERID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28059994911154771848)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(28059992325844771846)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P12_USERID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(81094745615386680102)
,p_branch_name=>'Go To Login'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27875489040772226124)
,p_name=>'P12_PROID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_source=>'PROID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27875489138694226125)
,p_name=>'P12_FULL_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_prompt=>'Full Name'
,p_source=>'FULL_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>70
,p_field_template=>wwv_flow_imp.id(27645616853958606449)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28059989563000771844)
,p_name=>'P12_USERID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Userid'
,p_source=>'USERID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28059989977707771844)
,p_name=>'P12_USERNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_prompt=>'Username'
,p_placeholder=>'--To Login--'
,p_source=>'USERNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(27645616853958606449)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28059990385842771844)
,p_name=>'P12_PASSCODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_prompt=>'Password'
,p_placeholder=>'--To Login--'
,p_source=>'PASSCODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645616853958606449)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28059990734783771845)
,p_name=>'P12_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28280788106580655515)
,p_name=>'P12_DESIGNATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_prompt=>'Designation'
,p_source=>'DESIGNATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>70
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28280788211064655516)
,p_name=>'P12_COMPANY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_prompt=>'Company Name'
,p_source=>'COMPANY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>500
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28280788328104655517)
,p_name=>'P12_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645616853958606449)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28280788496753655518)
,p_name=>'P12_CELL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_prompt=>'Cell'
,p_source=>'CELL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75944659233229265702)
,p_name=>'P12_ID_NO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_item_source_plug_id=>wwv_flow_imp.id(28059989294643771843)
,p_prompt=>'User Identification No.'
,p_source=>'ID_NO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>70
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645616853958606449)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(35095655009919306801)
,p_validation_name=>'MailValid'
,p_validation_sequence=>10
,p_validation=>'P12_EMAIL'
,p_validation2=>'^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Please enter valid email'
,p_associated_item=>wwv_flow_imp.id(28280788328104655517)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28059992881965771847)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28059992755657771847)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28059993688796771847)
,p_event_id=>wwv_flow_imp.id(28059992881965771847)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81094745719609680103)
,p_name=>'RemoveUser'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28059994188223771848)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81094745837260680104)
,p_event_id=>wwv_flow_imp.id(81094745719609680103)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'DELETE FROM TEAM_MEMBERS WHERE USERID = :BIND_USER_ID;',
'UPDATE TEAMS SET TEAM_LEADER = NULL WHERE TEAM_LEADER = :BIND_USER_ID;',
'UPDATE TEAMS SET SUB_LEADER = NULL WHERE SUB_LEADER = :BIND_USER_ID;',
'--It may violate unique constraint (user A:null-task:A user B:null-task:A) and the userid is not deactivated because of it',
'UPDATE USER_TASKS SET USERID = NULL WHERE USERID = :BIND_USER_ID;',
'UPDATE USER_TASKS SET UPD_BY = NULL WHERE UPD_BY = :BIND_USER_ID;',
'UPDATE USER_TASKS SET INS_BY = NULL WHERE INS_BY = :BIND_USER_ID;',
'UPDATE PROJECT_DETAILS SET INS_BY = NULL WHERE INS_BY = :BIND_USER_ID;',
'UPDATE PROJECT_DETAILS SET UPD_BY = NULL WHERE UPD_BY = :BIND_USER_ID;',
'UPDATE PROJECT_DETAILS SET STS_BY = NULL WHERE STS_BY = :BIND_USER_ID;',
'DELETE FROM USERS_ROLE WHERE USERID = :BIND_USER_ID;',
'DELETE FROM USER_TABLES WHERE USERID = :BIND_USER_ID;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'NULL;',
'WHEN OTHERS THEN ',
'NULL;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81094745951427680105)
,p_event_id=>wwv_flow_imp.id(81094745719609680103)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81094746669831680112)
,p_name=>'Updating'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(28059994591728771848)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81094746789104680113)
,p_event_id=>wwv_flow_imp.id(81094746669831680112)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE user_tables',
'SET USERNAME = :P12_USERNAME,',
'    PASSCODE = encrypto(:P12_PASSCODE),',
'    STATUS = :P12_STATUS,',
'    FULL_NAME = :P12_FULL_NAME,',
'    DESIGNATION = :P12_DESIGNATION,',
'    COMPANY = :P12_COMPANY,',
'    EMAIL = :P12_EMAIL,',
'    CELL = :P12_CELL,',
'    ID_NO = :P12_ID_NO,',
'    PROID = :P12_PROID',
'WHERE USERID = :P12_USERID;',
'END;'))
,p_attribute_02=>'P12_USERID,P12_FULL_NAME,P12_ID_NO,P12_USERNAME,P12_PASSCODE,P12_CELL,P12_EMAIL,P12_COMPANY,P12_DESIGNATION,P12_STATUS,P12_PROID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81094746853713680114)
,p_event_id=>wwv_flow_imp.id(81094746669831680112)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27875488487905226118)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'pk'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (30) :=  NULL;',
'BEGIN',
'',
'    SELECT MAX (userid)',
'      INTO NEW_PK',
'      FROM user_tables;',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ',
'    :P12_USERID := NEW_PK;',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28059994911154771848)
,p_internal_uid=>27875488487905226118
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28059995794648771849)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(28059989294643771843)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Sign Up'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28059995794648771849
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28059996183223771849)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>28059996183223771849
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(78998280257785474315)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Make Everyone Authentic'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P12_USERID := :BIND_USER_ID;',
':P12_STATUS := ''Y'';',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>78998280257785474315
,p_process_comment=>'must remove or change it with ''N'''
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28059995332231771848)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(28059989294643771843)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Sign Up'
,p_internal_uid=>28059995332231771848
);
wwv_flow_imp.component_end;
end;
/
