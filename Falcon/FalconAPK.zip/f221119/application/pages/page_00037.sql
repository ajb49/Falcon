prompt --application/pages/page_00037
begin
--   Manifest
--     PAGE: 00037
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>37
,p_name=>'Status Report'
,p_alias=>'STATUS-REPORT'
,p_page_mode=>'MODAL'
,p_step_title=>'Status Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_dialog_width=>'400'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231025051619'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4393899986508484901)
,p_plug_name=>'WORKLOAD'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4393900260341484904)
,p_plug_name=>'ACTION'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645481003320606385)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4393900325457484905)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4393900260341484904)
,p_button_name=>'SUBMIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(27645618115673606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4393900089874484902)
,p_name=>'P37_TASK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4393899986508484901)
,p_prompt=>'Assign'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TASK_NAME||'' ::''||(SELECT PROJECT_NAME FROM PROJECTS WHERE PROJECTS.PROJECT_ID = i.PROJECT_ID) D,',
'       PROID R',
'  from PROJECT_DETAILS i',
'  where status not in (''1'',''4'',''5'')',
'  and proid in ((select proid from user_tasks where userid IN :BIND_USER_ID))',
'order by proid desc;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4393900140906484903)
,p_name=>'P37_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4393899986508484901)
,p_prompt=>'Action'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PROJECT STATUS'
,p_lov=>'.'||wwv_flow_imp.id(27651661124332706306)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615432697606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4525014662774296901)
,p_name=>'P37_REMAINED'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4393899986508484901)
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5117373171689356501)
,p_name=>'P37_UPD_BY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4393899986508484901)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5117373230575356502)
,p_name=>'P37_UPD_DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4393899986508484901)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4393900476922484906)
,p_name=>'SHOWSTAT'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P37_TASK'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4393900536628484907)
,p_event_id=>wwv_flow_imp.id(4393900476922484906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'select STATUS',
', CASE ',
'    WHEN TRUNC(end_to - sysdate) > 0 THEN '' Remained: ''||TRUNC(end_to - sysdate)||'' Day(s)''',
'    WHEN TRUNC(end_to - sysdate) = 0 THEN ''1 Day left''',
'    WHEN TRUNC(end_to - sysdate) < 0 THEN '' Overdue: ''||abs(TRUNC(end_to - sysdate))||'' Day(s)''',
'    END remain',
'INTO :P37_STATUS, :P37_REMAINED',
'  from PROJECT_DETAILS i',
'  where  proid = :P37_TASK;',
'',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'NULL;',
'WHEN OTHERS THEN',
'NULL;',
'END;'))
,p_attribute_02=>'P37_TASK'
,p_attribute_03=>'P37_STATUS,P37_REMAINED'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4393900937551484911)
,p_name=>'UpdateTask'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(4393900325457484905)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4393901059841484912)
,p_event_id=>wwv_flow_imp.id(4393900937551484911)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'if :P37_TASK is not null and :P37_STATUS is not null then',
'UPDATE project_details',
'SET status = :P37_STATUS,',
'upd_by = :P37_UPD_BY,',
'sts_by = :P37_UPD_BY,   --adjustment',
'upd_date = :P37_UPD_DATE',
'WHERE proid = :P37_TASK;',
'  IF :P37_STATUS = ''1'' THEN',
'    UPDATE project_details',
'    SET upd_done = CURRENT_TIMESTAMP',
'    WHERE proid = :P37_TASK;',
'  ELSIF :P37_STATUS <> ''1'' THEN',
'  NULL;',
'  END IF;',
'',
'else',
'null;',
'end if;',
'exception',
'when no_data_found then',
'null;',
'when others then',
'null;',
'',
'END;'))
,p_attribute_02=>'P37_TASK,P37_STATUS,P37_UPD_BY,P37_UPD_DATE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4393901161661484913)
,p_event_id=>wwv_flow_imp.id(4393900937551484911)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4393900830396484910)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'cln'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_internal_uid=>4393900830396484910
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5117373437640356504)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DEFAULTVALUE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P37_UPD_BY := :BIND_USER_ID;',
':P37_UPD_DATE := CURRENT_TIMESTAMP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5117373437640356504
);
wwv_flow_imp.component_end;
end;
/
