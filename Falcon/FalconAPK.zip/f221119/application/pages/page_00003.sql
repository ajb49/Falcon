prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'User Task'
,p_alias=>'USER-TASK'
,p_page_mode=>'MODAL'
,p_step_title=>'User Task'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'650'
,p_dialog_width=>'1200'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231018050633'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28090699022678818247)
,p_plug_name=>'User Task'
,p_region_name=>'REGIONID'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders:t-Form--noPadding:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(27645535011037606409)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select UT.ROWID,',
'       UT.USERID,',
'       UT.PROID,',
'       UT.INS_BY,',
'       UT.INS_DATE,',
'       UT.UPD_BY,',
'       UT.UPD_DATE, UT.team_id',
'       ,status,',
'        '''' button,',
'        UT.PROID PROID_SORT,',
'        '''' attachment',
'  from USER_TASKS UT, PROJECT_DETAILS PD',
'  where UT.PROID = PD.PROID',
' AND (UT.team_id = :P3_TEAM)',
' AND ut.userid IN (SELECT USERID FROM USER_TASKS WHERE TEAM_ID = :P3_TEAM)',
' AND (ut.proid IN (SELECT PROID FROM USER_TASKS WHERE TEAM_ID = :BIND_TEAM_ID) OR ut.proid is null)',
'  and status in (''0'',''2'',''3'')'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P3_TEAM'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'User Task'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(27875489287921226126)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(27875489334944226127)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(27875489522995226129)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28090700378770818249)
,p_name=>'USERID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT (select full_name from user_tables ut where ut.userid = tm.userid and status = ''Y'')||'' (''||(select email||'' ''||id_no from user_tables ut where ut.userid = tm.userid and status = ''Y'')||'')'' full_name ,userid',
'from team_members tm',
'where (team_id = :P3_TEAM) ',
'or (userid in (select userid from user_tasks where team_id = :P3_TEAM))  ',
'--(team_id = :P3_TEAM )',
'order by 2 asc, 2 nulls last'))
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'TEAM_ID'
,p_ajax_items_to_submit=>'TEAM_ID'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28280790105902655535)
,p_name=>'INS_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INS_BY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28280790225149655536)
,p_name=>'INS_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INS_DATE'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28280790371133655537)
,p_name=>'UPD_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPD_BY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(28280790448253655538)
,p_name=>'UPD_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPD_DATE'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29494190093033735521)
,p_name=>'TEAM_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEAM_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'N'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(30534585434796991604)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(34660348184076309801)
,p_name=>'BUTTON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BUTTON'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'&nbsp'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_link_target=>'#'
,p_link_text=>'<button id="mail_id" class=" fa fa-envelope" aria-hidden="true"></button>'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_escape_on_http_output=>true
,p_column_comment=>'value="#ROWID#" class="buttonid t-Button t-Button--success t-Button--hot t-Button--stretch"'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(36328483904866107901)
,p_name=>'PROID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Task'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(28090599154033807129)
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(36934492349328807801)
,p_name=>'PROID_SORT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROID_SORT'
,p_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Proid Sort'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43408025643973002510)
,p_name=>'ATTACHMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ATTACHMENT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Attachment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:CR,17:P17_PROID:&PROID.'
,p_link_text=>'<span class="fa fa-paperclip" aria-hidden="true"></span>'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(28090699514042818248)
,p_internal_uid=>28090699514042818248
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:RESET:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>400
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {  ',
'',
'   config.defaultGridViewOptions = {  ',
'',
'   footer: false',
'',
'}  ',
'',
'return config;  ',
'',
'}  '))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(28090699987206818248)
,p_interactive_grid_id=>wwv_flow_imp.id(28090699514042818248)
,p_static_id=>'280907000'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(28090700110156818248)
,p_report_id=>wwv_flow_imp.id(28090699987206818248)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(315377368006184)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(36934492349328807801)
,p_is_visible=>false
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(28090700793944818249)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(28090700378770818249)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>144
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(28091160030470820929)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(27875489287921226126)
,p_is_visible=>true
,p_is_frozen=>true
,p_width=>58
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(28091161215882820934)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(27875489522995226129)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(28317042321086562716)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(28280790105902655535)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(28317043270313562720)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(28280790225149655536)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(28317044163254562723)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(28280790371133655537)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(28317045056246562725)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(28280790448253655538)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29507119525710200568)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(29494190093033735521)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(30552486619539816492)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(30534585434796991604)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(34660867357984797235)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(34660348184076309801)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>49
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(36328722374572596096)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(36328483904866107901)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>731.2
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44099045660673270966)
,p_view_id=>wwv_flow_imp.id(28090700110156818248)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(43408025643973002510)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>110
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29494190135087735522)
,p_plug_name=>'TEAMBLOCK'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_source=>'<div align="right"><i>To send mail, Please select the row by double clicking</i></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29494190269910735523)
,p_name=>'P3_TEAM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(29494190135087735522)
,p_prompt=>'Assign to another team'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TEAM'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29494191364980735534)
,p_name=>'P3_TEAM_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(29494190135087735522)
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35619916826584218308)
,p_name=>'P3_ROWID2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(29494190135087735522)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35623479002523290505)
,p_name=>'P3_ROWIDSELECTD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(29494190135087735522)
,p_prompt=>'&nbsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29494190867290735529)
,p_name=>'RefreshRate'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_TEAM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29494190940742735530)
,p_event_id=>wwv_flow_imp.id(29494190867290735529)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28090699022678818247)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35114802539764917703)
,p_event_id=>wwv_flow_imp.id(29494190867290735529)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'USERID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34660348237508309802)
,p_name=>'SendMail'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#mail_id'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34660348989147309809)
,p_event_id=>wwv_flow_imp.id(34660348237508309802)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sending e-mail!'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34660348388444309803)
,p_event_id=>wwv_flow_imp.id(34660348237508309802)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P3_ROWID2 IS NOT NULL THEN',
'project_mail_to_assignee(:P3_ROWID2);',
'ELSE',
'RAISE_APPLICATION_ERROR(-20007,''Please Double Click On Cell and Send'');',
'END IF;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'RAISE_APPLICATION_ERROR(-20006,''Execution of mailing has problem!'');',
'END;'))
,p_attribute_02=>'P3_ROWID2'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34660349296103309812)
,p_event_id=>wwv_flow_imp.id(34660348237508309802)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35619916427437218304)
,p_name=>'New_1'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(28090699022678818247)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35619916567580218305)
,p_event_id=>wwv_flow_imp.id(35619916427437218304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_ROWID'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var row_id',
'model=this.data.model;',
'if(this.data != null){',
'if(this.data.selectedRecords[0]!=null){',
'row_id = model.getValue(this.data.selectedRecords[0],"ROWID")}}',
'',
'apex.item("P13_ROW").setValue(row_id);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35619916697517218306)
,p_event_id=>wwv_flow_imp.id(35619916427437218304)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_ROWID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35623478683798290501)
,p_name=>'New'
,p_event_sequence=>50
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(28090699022678818247)
,p_triggering_element=>'BUTTON'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35623478777713290502)
,p_event_id=>wwv_flow_imp.id(35623478683798290501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_ROWID2'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':ROWID'
,p_attribute_07=>'ROWID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35623479129898290506)
,p_name=>'mailsendok'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_ROWID2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35623479230915290507)
,p_event_id=>wwv_flow_imp.id(35623479129898290506)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v___name user_tables.full_name%type;',
'begin',
'if :P3_ROWID2 is not null then',
'select full_name into v___name from user_tables where userid = (select userid from user_tasks where rowid = :P3_ROWID2);',
'',
unistr(':P3_ROWIDSELECTD := ''\2714 You can send email to ''||v___name;'),
'else',
':P3_ROWIDSELECTD := ''-'';',
'end if;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'NULL;',
'WHEN OTHERS THEN',
'NULL;',
'end;'))
,p_attribute_02=>'P3_ROWID2'
,p_attribute_03=>'P3_ROWIDSELECTD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27875489418980226128)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(28090699022678818247)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'User Task - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    case :APEX$ROW_STATUS',
'    when ''C'' then',
'        insert into USER_TASKS (  USERID, PROID, INS_BY, INS_DATE, UPD_BY, UPD_DATE,team_id )',
'        values (  :USERID, :PROID, :BIND_USER_ID, CURRENT_TIMESTAMP, NULL, NULL, :BIND_TEAM_ID )',
'        returning rowid into :ROWID;',
'       -- project_mail_to_assignee(:rowid);',
'BEGIN',
'DECLARE',
'v___person INTEGER;',
'BEGIN',
'SELECT COUNT(*) ',
'INTO v___person',
'FROM USER_TASKS j ',
'WHERE j.proid = :PROID;',
'UPDATE project_details',
'SET person = v___person',
'WHERE proid = :PROID;',
'END;',
'END;',
'    when ''U'' then',
'        update USER_TASKS',
'           set  USERID = :USERID, ',
'           PROID = :PROID, ',
'           UPD_BY = :BIND_USER_ID, ',
'           UPD_DATE = CURRENT_TIMESTAMP,',
'           TEAM_ID = :BIND_TEAM_ID',
'         where rowid  = :ROWID;',
'                -- project_mail_to_assignee(:rowid);',
'                BEGIN',
'DECLARE',
'v___person INTEGER;',
'BEGIN',
'SELECT COUNT(*) ',
'INTO v___person',
'FROM USER_TASKS j ',
'WHERE j.proid = :PROID;',
'UPDATE project_details',
'SET person = v___person',
'WHERE proid = :PROID;',
'END;',
'END;',
'    when ''D'' then',
'        delete USER_TASKS',
'         where rowid = :ROWID;',
'BEGIN',
'DECLARE',
'v___person INTEGER;',
'BEGIN',
'SELECT COUNT(*) ',
'INTO v___person',
'FROM USER_TASKS j ',
'WHERE j.proid = :PROID;',
'UPDATE project_details',
'SET person = v___person',
'WHERE proid = :PROID;',
'END;',
'END;',
'    end case;',
'end;'))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27875489418980226128
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35623478883656290503)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'CrearRowidToSendWrongMAil'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P3_ROWID2,P3_ROWIDSELECTD'
,p_internal_uid=>35623478883656290503
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29494191278762735533)
,p_process_sequence=>20
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetValue'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'SELECT team_id',
'INTO :P3_TEAM',
'FROM TEAMS',
'WHERE TEAM_ID = :BIND_TEAM_ID;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P3_TEAM := null;',
'END;',
'',
'BEGIN',
'SELECT TEAM_NAME',
'INTO :P3_TEAM_NAME',
'FROM TEAMS',
'WHERE TEAM_ID = :BIND_TEAM_ID;',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
':P3_TEAM_NAME := ''Anonymus Team'';',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>29494191278762735533
);
wwv_flow_imp.component_end;
end;
/
