prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>28
,p_name=>'Upcoming Task'
,p_alias=>'UPCOMING-TASK'
,p_page_mode=>'MODAL'
,p_step_title=>'Upcoming Task'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1500'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230727182042'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(73034215751637347858)
,p_name=>'Detail'
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (select team_name from teams t where t.team_id=ut.team_id) team,',
'(select nvl(project_name,''No Name'') from projects p where p.project_id=pd.project_id) projects, ',
'task_name task, pd.proid,',
'person',
'FROM project_details pd, user_tasks ut',
'WHERE pd.proid=ut.proid',
'AND TO_CHAR(sysdate,''mm/dd/yyyy'') < TO_CHAR(start_from,''mm/dd/yyyy'')',
'and status not in (''1'', ''4'')',
'AND person is not null',
'AND project_id is not null',
'order by 1 asc, 2 asc, 3 asc, 4 desc;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P28_STATUS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_num_rows=>8
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'1:2:3'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(36684731248256836353)
,p_query_column_id=>1
,p_column_alias=>'TEAM'
,p_column_display_sequence=>10
,p_column_heading=>'Team'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(36684731647316836354)
,p_query_column_id=>2
,p_column_alias=>'PROJECTS'
,p_column_display_sequence=>20
,p_column_heading=>'Projects'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(36684732013154836354)
,p_query_column_id=>3
,p_column_alias=>'TASK'
,p_column_display_sequence=>30
,p_column_heading=>'Task'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(36684730844749836353)
,p_query_column_id=>4
,p_column_alias=>'PROID'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(36684732421318836354)
,p_query_column_id=>5
,p_column_alias=>'PERSON'
,p_column_display_sequence=>40
,p_column_heading=>'Person'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::P4_PROID:#PROID#'
,p_column_linktext=>'#PERSON#'
,p_column_alignment=>'CENTER'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73034216246358347863)
,p_plug_name=>'Value'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73034219471992347878)
,p_name=>'P28_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(73034216246358347863)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36684733714548836368)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P28_STATUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36684734234322836369)
,p_event_id=>wwv_flow_imp.id(36684733714548836368)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(73034215751637347858)
);
wwv_flow_imp.component_end;
end;
/
