prompt --application/pages/page_00034
begin
--   Manifest
--     PAGE: 00034
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>34
,p_name=>'Team Members'
,p_alias=>'TEAM-MEMBERS'
,p_page_mode=>'MODAL'
,p_step_title=>'Team Members'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231021095838'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(80185191912944155910)
,p_name=>'TEAM MEMBERS'
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select team_id,',
'listagg(''<p style="border-left: solid gray";> &nbsp;&nbsp;''||(select full_name||''<br>&nbsp;&nbsp;''||id_no||''<br>&nbsp;&nbsp;''||email||''<br>&nbsp;&nbsp;''||designation||'' ''||company from user_tables ut where ut.userid = tm.userid and status = ''Y'')',
',''<p style="border-left: solid gray";>'') within group (order by team_id) USR',
'from team_members tm',
'WHERE team_id = :BIND_TEAM_ID',
'group by team_id',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645583006451606432)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>1000000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80185192032811155911)
,p_query_column_id=>1
,p_column_alias=>'TEAM_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80185192100769155912)
,p_query_column_id=>2
,p_column_alias=>'USR'
,p_column_display_sequence=>20
,p_column_heading=>'Usr'
,p_column_format=>'PCT_GRAPH:::'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
