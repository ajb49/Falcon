prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'New Project'
,p_alias=>'NEW-PROJECT'
,p_page_mode=>'MODAL'
,p_step_title=>'New Project'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231021051340'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27646205367288103376)
,p_plug_name=>'New Project'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'PROJECTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27646207765656103384)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645481003320606385)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27646208106905103385)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27646207765656103384)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27646209540009103386)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(27646207765656103384)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P2_PROJECT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27646209918650103386)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(27646207765656103384)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P2_PROJECT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27646210314514103386)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(27646207765656103384)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P2_PROJECT_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27646205621001103377)
,p_name=>'P2_PROJECT_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Project Id'
,p_source=>'PROJECT_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27646206086414103383)
,p_name=>'P2_PROJECT_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_prompt=>'Project Name'
,p_source=>'PROJECT_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(27645616853958606449)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27646206403819103384)
,p_name=>'P2_PROJECT_DESCRIPTION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_prompt=>'Project Description'
,p_source=>'PROJECT_DESCRIPTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27875486901779226103)
,p_name=>'P2_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_prompt=>'Project Activity'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Active;Y,Inactive;N'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27875487090263226104)
,p_name=>'P2_CHECK_IN'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_prompt=>'Project Start'
,p_format_mask=>'DD-MON-RR'
,p_source=>'CHECK_IN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645616853958606449)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27875487154622226105)
,p_name=>'P2_CHECK_OUT'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_prompt=>'Project End'
,p_format_mask=>'DD-MON-RR'
,p_source=>'CHECK_OUT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645616853958606449)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27875487533259226109)
,p_name=>'P2_COMMENTS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_default=>'N'
,p_prompt=>'Project Status'
,p_source=>'COMMENTS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Completed;Y,Incompleted;N'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29494190433876735525)
,p_name=>'P2_TEAM_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_default=>':BIND_TEAM_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Team'
,p_source=>'TEAM_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TEAM'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Anonymus --'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30534588126051991631)
,p_name=>'P2_ROOT_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_item_source_plug_id=>wwv_flow_imp.id(27646205367288103376)
,p_prompt=>'Head Project'
,p_source=>'ROOT_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'PROJECT_NAME'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROJECT_ID,  PROJECT_NAME',
'                    ||'': ''',
'                    ||TO_CHAR(CHECK_OUT,''DD-MON-YY'')',
'                    ||'' [ ''',
'                    ||(SELECT nvl(team_name,''No Team'') FROM teams WHERE teams.team_id = projects.team_id)',
'                    ||'' ]'' PROJECT_NAME ',
'from PROJECTS ',
'where (TEAM_ID = :BIND_TEAM_ID ',
'OR ',
'project_id in (SELECT project_id FROM projects WHERE project_id in (select project_id from project_details where proid in (select proid from user_tasks where userid = :BIND_USER_ID)))',
') ',
'AND STATUS IN (''Y'')',
'-- select PROJECT_ID, PROJECT_NAME||'': ''||TO_CHAR(CHECK_OUT,''DD-MON'') PROJECT_NAME ',
'-- from PROJECTS ',
'-- where (TEAM_ID = :BIND_TEAM_ID ',
'-- OR ',
'-- project_id in (SELECT project_id FROM projects WHERE project_id in (select project_id from project_details where proid in (select proid from user_tasks where userid = :BIND_USER_ID)))',
'-- ) ',
'-- AND STATUS IN (''Y'');'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select Parent Project --'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(35082224666773749908)
,p_validation_name=>'MustGiven'
,p_validation_sequence=>10
,p_validation=>'P2_PROJECT_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'You must enter Project Name'
,p_associated_item=>wwv_flow_imp.id(27646206086414103383)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(35082224771915749909)
,p_validation_name=>'MustGiven_1'
,p_validation_sequence=>20
,p_validation=>'P2_CHECK_IN'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'You must enter Check In Date'
,p_associated_item=>wwv_flow_imp.id(27875487090263226104)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(35082224859017749910)
,p_validation_name=>'MustGiven_1_1'
,p_validation_sequence=>30
,p_validation=>'P2_CHECK_OUT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'You must enter Check Out Date'
,p_associated_item=>wwv_flow_imp.id(27875487154622226105)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(27646208224329103385)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(27646208106905103385)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27646209081991103386)
,p_event_id=>wwv_flow_imp.id(27646208224329103385)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28280790520816655539)
,p_name=>'MakeNAlart'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_STATUS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28280790682750655540)
,p_event_id=>wwv_flow_imp.id(28280790520816655539)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'After Inactive Project, All pending, halt & Overdue data will be gone for &P2_PROJECT_NAME. !'
,p_attribute_02=>'Are you sure !'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P2_STATUS'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33361452307573068701)
,p_name=>'FillAsParent'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_ROOT_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33361452456872068702)
,p_event_id=>wwv_flow_imp.id(33361452307573068701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'IF :P2_CHECK_OUT IS NOT NULL THEN',
'null;',
'ELSIF :P2_CHECK_OUT IS NULL THEN',
'SELECT to_char(check_out,''DD-MON-RR'')',
'INTO :P2_CHECK_OUT',
'FROM projects',
'WHERE project_id = :P2_ROOT_ID;',
'END IF;',
'EXCEPTION ',
'WHEN NO_DATA_FOUND THEN',
'NULL;',
'end;'))
,p_attribute_02=>'P2_ROOT_ID'
,p_attribute_03=>'P2_CHECK_OUT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33361452555798068703)
,p_event_id=>wwv_flow_imp.id(33361452307573068701)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_CHECK_OUT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27646624986963125711)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'pk'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (30) :=  NULL;',
'BEGIN',
'',
'    SELECT MAX (project_id)',
'      INTO NEW_PK',
'      FROM projects;',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ',
'    :P2_PROJECT_ID := NEW_PK;',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(27646210314514103386)
,p_internal_uid=>27646624986963125711
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27646211181329103387)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(27646205367288103376)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form New Project'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27646211181329103387
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27646211530113103387)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>27646211530113103387
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27646210797365103387)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(27646205367288103376)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form New Project'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>27646210797365103387
);
wwv_flow_imp.component_end;
end;
/
