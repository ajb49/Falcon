prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Add New Team'
,p_alias=>'ADD-NEW-TEAM'
,p_page_mode=>'MODAL'
,p_step_title=>'Add New Team'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231021084415'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29485546937765417711)
,p_plug_name=>'Add New Team'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'TEAMS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29485550056017417714)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645481003320606385)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29485550413429417715)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(29485550056017417714)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29485551887108417716)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(29485550056017417714)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P11_TEAM_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29485552293335417716)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(29485550056017417714)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P11_TEAM_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29485552634552417716)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(29485550056017417714)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P11_TEAM_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(35460126440765696001)
,p_branch_name=>'Go_to_sign_in'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:RR,9999::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'CREATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29485547250232417712)
,p_name=>'P11_TEAM_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(29485546937765417711)
,p_item_source_plug_id=>wwv_flow_imp.id(29485546937765417711)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Team Id'
,p_source=>'TEAM_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29485547601994417712)
,p_name=>'P11_TEAM_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(29485546937765417711)
,p_item_source_plug_id=>wwv_flow_imp.id(29485546937765417711)
,p_prompt=>'Team Name'
,p_source=>'TEAM_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>70
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29485548077926417713)
,p_name=>'P11_TEAM_LEADER'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(29485546937765417711)
,p_item_source_plug_id=>wwv_flow_imp.id(29485546937765417711)
,p_prompt=>'Team Leader'
,p_source=>'TEAM_LEADER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT full_name||'' (''||email||'' - ''||id_no||'')'' d, ut.userid r',
'FROM user_tables ut, users_role ur',
'where ut.userid = ur.userid',
'AND ut.status IN (''Y'',''N'')',
'and :BIND_USER_ROLE IN (1000,1001)',
'and :BIND_USER_ID IS NOT NULL',
'order by 1 asc',
'-- select distinct (select full_name||'' (''||email||'' - ''||id_no||'')'' d from user_tables ut where ut.userid = tm.userid and status = ''Y'') full_name, userid r ',
'-- from team_members tm',
'-- where (team_id = :BIND_TEAM_ID or :P11_TEAM_ID is null)',
'-- and :BIND_USER_ROLE IN (1000,1001)',
'-- order by 2 asc, 2 nulls last;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29485548498454417713)
,p_name=>'P11_SUB_LEADER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(29485546937765417711)
,p_item_source_plug_id=>wwv_flow_imp.id(29485546937765417711)
,p_prompt=>'Sub Leader'
,p_source=>'SUB_LEADER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT full_name||'' (''||email||'' - ''||id_no||'')'' d, ut.userid r',
'FROM user_tables ut, users_role ur',
'where ut.userid = ur.userid',
'AND ut.status IN (''Y'',''N'')',
'and :BIND_USER_ROLE IN (1000,1001)',
'and :BIND_USER_ID IS NOT NULL',
'order by 1 asc',
'-- select distinct (select full_name||'' (''||email||'' - ''||id_no||'')'' d from user_tables ut where ut.userid = tm.userid and status = ''Y'') full_name, userid r ',
'-- from team_members tm',
'-- where (team_id = :BIND_TEAM_ID or :P11_TEAM_ID is null)',
'-- and :BIND_USER_ROLE IN (1000,1001)',
'-- order by 2 asc, 2 nulls last;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29485550516054417715)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(29485550413429417715)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29485551337749417715)
,p_event_id=>wwv_flow_imp.id(29485550516054417715)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28720456091966109029)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (30) :=  NULL;',
'BEGIN',
'',
'    SELECT MAX (team_id)',
'      INTO NEW_PK',
'      FROM teams;',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ',
'    :P11_TEAM_ID := NEW_PK;',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28720456091966109029
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29485553455030417717)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(29485546937765417711)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Add New Team'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>29485553455030417717
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29485553828155417717)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>29485553828155417717
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29485553010276417716)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(29485546937765417711)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Add New Team'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>29485553010276417716
);
wwv_flow_imp.component_end;
end;
/
