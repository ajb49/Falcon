prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Falcon'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Footer {',
'    ',
'    display: none;',
'    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231029191003'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27646625894781125720)
,p_plug_name=>'BLOCK1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_footer=>'<hr>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3746352135366298606)
,p_plug_name=>'RBLOCK'
,p_parent_plug_id=>wwv_flow_imp.id(27646625894781125720)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3746351602753298601)
,p_plug_name=>'PROJECT_LIFE'
,p_parent_plug_id=>wwv_flow_imp.id(3746352135366298606)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>30
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(3746351737688298602)
,p_region_id=>wwv_flow_imp.id(3746351602753298601)
,p_chart_type=>'bar'
,p_title=>'Project Lifetime'
,p_height=>'250'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(3746351865260298603)
,p_chart_id=>wwv_flow_imp.id(3746351737688298602)
,p_seq=>10
,p_name=>'ProjectLifeTime'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT project_id, project_name, project_description, check_in, ',
'TRUNC( ',
'    check_out - sysdate',
') ',
'',
'p_life_time, ',
'status, comments, team_id',
'FROM projects',
'WHERE status = ''Y''',
'and (team_id = :BIND_TEAM_ID or :BIND_TEAM_ID IS NULL)',
'ORDER BY p_life_time, project_name;'))
,p_items_value_column_name=>'P_LIFE_TIME'
,p_items_label_column_name=>'PROJECT_NAME'
,p_color=>'#60759f'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(3746351989094298604)
,p_chart_id=>wwv_flow_imp.id(3746351737688298602)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(3746352024553298605)
,p_chart_id=>wwv_flow_imp.id(3746351737688298602)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Days'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3746352200936298607)
,p_plug_name=>'LBLOCK'
,p_parent_plug_id=>wwv_flow_imp.id(27646625894781125720)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(27646625945709125721)
,p_name=>'COUNT_BLOCK'
,p_parent_plug_id=>wwv_flow_imp.id(3746352200936298607)
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>10
,p_region_sub_css_classes=>'hover-badge'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--xlarge:t-BadgeList--circular:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'',
'(SELECT COUNT(*) ',
'FROM project_details',
'WHERE status = ''0''',
'and person is not null',
'and project_id is not null',
'and team_id = :BIND_TEAM_ID) AS "RUNNING"',
',',
'--overdue project',
'(SELECT COUNT(*) ',
'FROM project_details',
'WHERE status = ''2''',
'and person is not null',
'and project_id is not null',
'and team_id = :BIND_TEAM_ID) AS "OVERDUE"',
',',
'--done project',
'(SELECT COUNT(*) ',
'FROM project_details',
'WHERE status = ''1''',
'and person is not null',
'and project_id is not null',
'and team_id = :BIND_TEAM_ID) AS "COMPLETED"',
',',
'--upcoming project',
'(SELECT COUNT(*) ',
'FROM project_details',
'WHERE TO_CHAR(sysdate,''mm/dd/yyyy'') < TO_CHAR(start_from,''mm/dd/yyyy'')',
'and project_id is not null',
'and status not in (''1'', ''4'')',
'and team_id = :BIND_TEAM_ID) AS "UPCOMING"',
',',
'--total project',
'(SELECT COUNT(*)',
'FROM projects',
'where status = ''Y''',
'and team_id = :BIND_TEAM_ID) AS "TOTAL PROJECTS"',
'FROM DUAL;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645565058248606423)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27646626041883125722)
,p_query_column_id=>1
,p_column_alias=>'RUNNING'
,p_column_display_sequence=>10
,p_column_heading=>'Running'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RR,27:P27_STATUS:0'
,p_column_linktext=>'#RUNNING#'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27646626174942125723)
,p_query_column_id=>2
,p_column_alias=>'OVERDUE'
,p_column_display_sequence=>20
,p_column_heading=>'Overdue'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RR,27:P27_STATUS:2'
,p_column_linktext=>'#OVERDUE#'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27646626202102125724)
,p_query_column_id=>3
,p_column_alias=>'COMPLETED'
,p_column_display_sequence=>30
,p_column_heading=>'Completed'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RR,27:P27_STATUS:1'
,p_column_linktext=>'#COMPLETED#'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27646626383878125725)
,p_query_column_id=>4
,p_column_alias=>'UPCOMING'
,p_column_display_sequence=>40
,p_column_heading=>'Upcoming'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#UPCOMING#'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27646626483630125726)
,p_query_column_id=>5
,p_column_alias=>'TOTAL PROJECTS'
,p_column_display_sequence=>50
,p_column_heading=>'Total Projects'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RR,10::'
,p_column_linktext=>'#TOTAL PROJECTS#'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(27646627291838125734)
,p_name=>'PROGRESS_BLOCK'
,p_parent_plug_id=>wwv_flow_imp.id(3746352200936298607)
,p_template=>wwv_flow_imp.id(27645478217567606384)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ROUND(((',
'    (SELECT COUNT(*) FROM project_details WHERE status = ''1'' and team_id = :BIND_TEAM_ID) ',
'    /  ',
'nvl(case when (SELECT COUNT(*) FROM project_details WHERE team_id = :BIND_TEAM_ID) = 0 ',
'            then 0.00001',
'         when (SELECT COUNT(*) FROM project_details WHERE team_id = :BIND_TEAM_ID) > 0 ',
'            then (SELECT COUNT(*) FROM project_details WHERE team_id = :BIND_TEAM_ID)',
'         else null end,0.00001)',
'-- nvl(case when :L = 0 then ''0.00001''',
'-- when :L > 0 then :L',
'-- else null end,0.00001)',
'    ) * 100),2)||'' %'' progress_pct',
'FROM dual;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(27645565058248606423)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27646627390944125735)
,p_query_column_id=>1
,p_column_alias=>'PROGRESS_PCT'
,p_column_display_sequence=>10
,p_column_heading=>'Completed Percentage'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34818255772026442002)
,p_plug_name=>'BLOCK2'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>30
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28720455378012109022)
,p_plug_name=>'BARBLOCK'
,p_parent_plug_id=>wwv_flow_imp.id(34818255772026442002)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="border-left: solid gray";'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(28720455404726109023)
,p_region_id=>wwv_flow_imp.id(28720455378012109022)
,p_chart_type=>'bar'
,p_title=>'Project Outcome'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'Please add project'
,p_automatic_refresh_interval=>70
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(28720455548794109024)
,p_chart_id=>wwv_flow_imp.id(28720455404726109023)
,p_seq=>10
,p_name=>'Outcome'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''\2705 :''||suc'),
' lab, count(*) val',
'from projects , (select listagg(project_name,'', '') within group (order by project_name) suc from projects i where comments = ''Y'')',
'where comments = ''Y''',
unistr('group by ''\2705 :''||suc'),
'UNION',
unistr('select ''\274C :''||fai'),
'lab, count(*) val',
'from projects , (select listagg(project_name,'', '') within group (order by project_name) fai from projects n where status = ''N'' and comments = ''N'') ',
'where status = ''N'' and comments = ''N''',
unistr('group by ''\274C :''||fai'),
'UNION',
unistr('select ''\27A1\FE0F :''||alive'),
'lab, count(*) val',
'from projects , (select listagg(project_name,'', '') within group (order by project_name) alive from projects n where status = ''Y'' and comments = ''N'') ',
'where status = ''Y'' and comments = ''N''',
unistr('group by ''\27A1\FE0F :''||alive'),
'order by 2 asc, 1 desc;'))
,p_items_value_column_name=>'VAL'
,p_items_label_column_name=>'LAB'
,p_color=>'#ff8400'
,p_assigned_to_y2=>'on'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(30534586180110991611)
,p_chart_id=>wwv_flow_imp.id(28720455404726109023)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_title=>'Number of Project'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(28720455961440109028)
,p_chart_id=>wwv_flow_imp.id(28720455404726109023)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(28720455866365109027)
,p_chart_id=>wwv_flow_imp.id(28720455404726109023)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Circumstance'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34818256537426442010)
,p_plug_name=>'CHRT'
,p_parent_plug_id=>wwv_flow_imp.id(34818255772026442002)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-showMaximizeButton:t-Region--showIcon:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="border-left: solid gray";'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27645544873689606414)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>'based on tasks of projects and anonymous'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(34818256621114442011)
,p_region_id=>wwv_flow_imp.id(34818256537426442010)
,p_chart_type=>'bar'
,p_title=>'Team Performances'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_automatic_refresh_interval=>65
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(34818256772204442012)
,p_chart_id=>wwv_flow_imp.id(34818256621114442011)
,p_seq=>10
,p_name=>'Team Performance'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- SELECT (select team_name from teams t where t.team_id = ut.team_id) team,',
'--         SUM((NVL(ROUND(((EXTRACT(DAY FROM ins_date) - ',
'--         (select EXTRACT(DAY FROM upd_done) ',
'--         from project_details pd ',
'--         where pd.proid=ut.proid and status= 1)) / ',
'--         ((select EXTRACT(DAY FROM end_to) ',
'--         from project_details pd where pd.proid=ut.proid)+1 - ',
'--         EXTRACT(DAY FROM ins_date))) * 100,2),0)) / ',
'--         (select person from project_details pd where pd.proid=ut.proid))  performances',
'-- FROM user_tasks ut',
'-- WHERE team_id IS NOT NULL',
'-- GROUP BY team_id',
'-- order by performances nulls last, 2 desc',
'select team_name||''Total Task: ''||',
'(',
'    (count(round(',
'(((',
'   to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1 ',
')-(',
'    nvl(to_date((select NVL(to_char(upd_done,''MM/DD/YYYY''),to_char(end_to,''MM/DD/YYYY'')) from project_details pd where pd.proid=ut.proid))',
'-',
'to_date(LEAST(to_char((select ',
'                ins_date ',
'                from project_details pd ',
'                where ut.proid=pd.proid),''MM/DD/YYYY''),',
'                to_char((select ',
'                            start_from ',
'                            from project_details pd ',
'                            where pd.proid=ut.proid),''MM/DD/YYYY''),',
'                            nvl(to_char(ins_date,''MM/DD/YYYY''),',
'                            to_char((select ',
'                                    start_from ',
'                                    from project_details pd ',
'                                    where pd.proid=ut.proid),''MM/DD/YYYY'')))),0)+1',
'))/(',
'    to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1',
')) * 100,2)))',
')',
'',
' assign_to_team,',
'round(',
'(sum(round(',
'(((',
'   to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1 ',
')-(',
'    nvl(to_date((select NVL(to_char(upd_done,''MM/DD/YYYY''),to_char(end_to,''MM/DD/YYYY'')) from project_details pd where pd.proid=ut.proid))',
'-',
'to_date(LEAST(to_char((select ',
'                ins_date ',
'                from project_details pd ',
'                where ut.proid=pd.proid),''MM/DD/YYYY''),',
'                to_char((select ',
'                            start_from ',
'                            from project_details pd ',
'                            where pd.proid=ut.proid),''MM/DD/YYYY''),',
'                            nvl(to_char(ins_date,''MM/DD/YYYY''),',
'                            to_char((select ',
'                                    start_from ',
'                                    from project_details pd ',
'                                    where pd.proid=ut.proid),''MM/DD/YYYY'')))),0)+1',
'))/(',
'    to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1',
')) * 100,2)))',
'/',
'count(round(',
'(((',
'   to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1 ',
')-(',
'    nvl(to_date((select NVL(to_char(upd_done,''MM/DD/YYYY''),to_char(end_to,''MM/DD/YYYY'')) from project_details pd where pd.proid=ut.proid))',
'-',
'to_date(LEAST(to_char((select ',
'                ins_date ',
'                from project_details pd ',
'                where ut.proid=pd.proid),''MM/DD/YYYY''),',
'                to_char((select ',
'                            start_from ',
'                            from project_details pd ',
'                            where pd.proid=ut.proid),''MM/DD/YYYY''),',
'                            nvl(to_char(ins_date,''MM/DD/YYYY''),',
'                            to_char((select ',
'                                    start_from ',
'                                    from project_details pd ',
'                                    where pd.proid=ut.proid),''MM/DD/YYYY'')))),0)+1',
'))/(',
'    to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1',
')) * 100,2)),2) performance_rate',
',CASE',
'    WHEN uts.team_id = :BIND_TEAM_ID THEN ''#F13121''',
'    ELSE ''#6F8F84'' END CSS_TEAM',
'from user_tasks ut, (select team_id, team_name from teams) uts',
'where uts.team_id = ut.team_id',
'group by team_name, uts.team_id',
'order by 2 desc;'))
,p_items_value_column_name=>'PERFORMANCE_RATE'
,p_items_label_column_name=>'ASSIGN_TO_TEAM'
,p_color=>'&CSS_TEAM.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(35082224492955749906)
,p_chart_id=>wwv_flow_imp.id(34818256621114442011)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(35082224599769749907)
,p_chart_id=>wwv_flow_imp.id(34818256621114442011)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Points'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37180418497115355928)
,p_plug_name=>'PEOPLE_PERFORM'
,p_parent_plug_id=>wwv_flow_imp.id(34818255772026442002)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-showMaximizeButton:t-Region--showIcon:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27645544873689606414)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>'based on tasks of projects and anonymous'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(37180418503277355929)
,p_region_id=>wwv_flow_imp.id(37180418497115355928)
,p_chart_type=>'bar'
,p_title=>'Individual Performances'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_automatic_refresh_interval=>60
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(37180418650826355930)
,p_chart_id=>wwv_flow_imp.id(37180418503277355929)
,p_seq=>10
,p_name=>'Individual Performance'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select full_name||'' (''||id_no||'')''||'' Total Task: ''||',
'',
'(count(round(',
'(((',
'   to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1 ',
')-(',
'    nvl(to_date((select NVL(to_char(upd_done,''MM/DD/YYYY''),to_char(end_to,''MM/DD/YYYY'')) from project_details pd where pd.proid=ut.proid))',
'-',
'to_date(LEAST(to_char((select ',
'                ins_date ',
'                from project_details pd ',
'                where ut.proid=pd.proid),''MM/DD/YYYY''),',
'                to_char((select ',
'                            start_from ',
'                            from project_details pd ',
'                            where pd.proid=ut.proid),''MM/DD/YYYY''),',
'                            nvl(to_char(ins_date,''MM/DD/YYYY''),',
'                            to_char((select ',
'                                    start_from ',
'                                    from project_details pd ',
'                                    where pd.proid=ut.proid),''MM/DD/YYYY'')))),0)+1',
'))/(',
'    to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1',
')) * 100,2)))',
'',
'',
' assign_to_person,',
'round(',
'(sum(round(',
'(((',
'   to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1 ',
')-(',
'    nvl(to_date((select NVL(to_char(upd_done,''MM/DD/YYYY''),to_char(end_to,''MM/DD/YYYY'')) from project_details pd where pd.proid=ut.proid))',
'-',
'to_date(LEAST(to_char((select ',
'                ins_date ',
'                from project_details pd ',
'                where ut.proid=pd.proid),''MM/DD/YYYY''),',
'                to_char((select ',
'                            start_from ',
'                            from project_details pd ',
'                            where pd.proid=ut.proid),''MM/DD/YYYY''),',
'                            nvl(to_char(ins_date,''MM/DD/YYYY''),',
'                            to_char((select ',
'                                    start_from ',
'                                    from project_details pd ',
'                                    where pd.proid=ut.proid),''MM/DD/YYYY'')))),0)+1',
'))/(',
'    to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1',
')) * 100,2)))',
'/',
'count(round(',
'(((',
'   to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1 ',
')-(',
'    nvl(to_date((select NVL(to_char(upd_done,''MM/DD/YYYY''),to_char(end_to,''MM/DD/YYYY'')) from project_details pd where pd.proid=ut.proid))',
'-',
'to_date(LEAST(to_char((select ',
'                ins_date ',
'                from project_details pd ',
'                where ut.proid=pd.proid),''MM/DD/YYYY''),',
'                to_char((select ',
'                            start_from ',
'                            from project_details pd ',
'                            where pd.proid=ut.proid),''MM/DD/YYYY''),',
'                            nvl(to_char(ins_date,''MM/DD/YYYY''),',
'                            to_char((select ',
'                                    start_from ',
'                                    from project_details pd ',
'                                    where pd.proid=ut.proid),''MM/DD/YYYY'')))),0)+1',
'))/(',
'    to_date((select ',
'        end_to ',
'        from project_details pd ',
'        where ut.proid=pd.proid),''mm/dd/yyyy'') ',
'        - ',
'        to_date(LEAST(to_char((select ',
'                                ins_date ',
'                                from project_details pd ',
'                                where ut.proid=pd.proid),''mm/dd/yyyy''),',
'                                to_char((select ',
'                                            start_from ',
'                                            from project_details pd ',
'                                            where pd.proid=ut.proid),''mm/dd/yyyy''),',
'                                            nvl(to_char(ins_date,''mm/dd/yyyy''),',
'                                            to_char((select ',
'                                                        start_from ',
'                                                        from project_details pd ',
'                                                        where pd.proid=ut.proid),''mm/dd/yyyy''))))',
'                                                        +1',
')) * 100,2)),2) performance_rate',
',case ',
'    when ut.userid = :BIND_USER_ID then ''#F13121''',
'    else ''#337279'' end user_css',
'from user_tasks ut, (select userid, full_name,id_no, status from user_tables usr) uts',
'where uts.userid = ut.userid',
'and uts.status = ''Y''',
'group by full_name||'' (''||id_no||'')'',ut.userid',
'order by 2 desc;'))
,p_items_value_column_name=>'PERFORMANCE_RATE'
,p_items_label_column_name=>'ASSIGN_TO_PERSON'
,p_color=>'&USER_CSS.'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(37180418768821355931)
,p_chart_id=>wwv_flow_imp.id(37180418503277355929)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(37180418815966355932)
,p_chart_id=>wwv_flow_imp.id(37180418503277355929)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Points'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36500904007387055501)
,p_plug_name=>'Join A Team'
,p_region_name=>'msg'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(27645520491201606403)
,p_plug_display_sequence=>50
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE IN (''1002'') THEN',
'RETURN FALSE;',
'ELSE',
'RETURN TRUE;',
'END IF;',
'END;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36500904118791055502)
,p_plug_name=>'Msg'
,p_parent_plug_id=>wwv_flow_imp.id(36500904007387055501)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div align="center">',
'    <strong>If you act <i><u>ADMIN</u> or <u>CONTRIBUTOR</u> ROLE</i>, You can join a team or make a new team.<br>',
'    If you act <i><u>READER</u></i> or did not get any <i>ROLES</i>, Please contact with your admin.</strong></div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36500905076919055511)
,p_plug_name=>'ToJump'
,p_parent_plug_id=>wwv_flow_imp.id(36500904007387055501)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<br>'
,p_plug_header=>'<div align="center">'
,p_plug_footer=>'</div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78998278800879474301)
,p_plug_name=>'Self Authentication'
,p_parent_plug_id=>wwv_flow_imp.id(36500904007387055501)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'must remove',
'--function body server side condition',
'IF :BIND_USER_ROLE IS NULL',
'THEN RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78998280399292474316)
,p_plug_name=>'Manually Team Added'
,p_region_name=>'Manual2'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(27645520491201606403)
,p_plug_display_sequence=>70
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78998280633317474319)
,p_plug_name=>'Msg To First Team Leader'
,p_parent_plug_id=>wwv_flow_imp.id(78998280399292474316)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div align=center><l>You need to add your id into new team manually that you have added.',
'<br>',
'Please Go to <b>TEAM > TEAM STATUS</b> menu',
'<br>',
'From the right table, click blue pen',
'<br>',
'Now Select your name and select your team',
'<br>',
'Save change and Restart or Log out and then log in',
'<br>',
'Or Add manually from Join Button</l></dib>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80029983746639575001)
,p_plug_name=>'BLOCK3'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>40
,p_plug_source=>'<hr>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2380531655150787614)
,p_plug_name=>'PROJECTASK'
,p_parent_plug_id=>wwv_flow_imp.id(80029983746639575001)
,p_region_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="border-left: solid gray";'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2380531585429787613)
,p_plug_name=>'PARAM_'
,p_parent_plug_id=>wwv_flow_imp.id(2380531655150787614)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80029987666831575040)
,p_plug_name=>'Projects'
,p_parent_plug_id=>wwv_flow_imp.id(2380531655150787614)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(80029987786030575041)
,p_region_id=>wwv_flow_imp.id(80029987666831575040)
,p_chart_type=>'bar'
,p_title=>'Project Status'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'No Activity of this TEAM yet.'
,p_automatic_refresh_interval=>85
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(80029987802094575042)
,p_chart_id=>wwv_flow_imp.id(80029987786030575041)
,p_seq=>10
,p_name=>'Task'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT project_name projects, count(*) total_tasks',
'FROM project_details pd, projects p',
'WHERE p.project_id = pd.project_id',
'--AND pd.project_id is not null',
'AND (pd.team_id = :P1_P_TM or :P1_P_TM is null)',
'AND (pd.status = :P1_P_STS or :P1_P_STS is null)',
'AND (p.status = :P1_P_ACT_STS or :P1_P_ACT_STS is null)',
'GROUP BY project_name',
'ORDER BY 1;'))
,p_ajax_items_to_submit=>'P1_P_TM,P1_P_STS,P1_P_ACT_STS'
,p_items_value_column_name=>'TOTAL_TASKS'
,p_items_label_column_name=>'PROJECTS'
,p_color=>'#533b7a'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(80029987986453575043)
,p_chart_id=>wwv_flow_imp.id(80029987786030575041)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Projects'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_tick_label_font_color=>'#3f8440'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(80029988044129575044)
,p_chart_id=>wwv_flow_imp.id(80029987786030575041)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Total Task'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80029983819372575002)
,p_plug_name=>'Project Performance'
,p_parent_plug_id=>wwv_flow_imp.id(80029983746639575001)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(80029984312862575007)
,p_region_id=>wwv_flow_imp.id(80029983819372575002)
,p_chart_type=>'lineWithArea'
,p_title=>'Project Performances'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'No Activity of this TEAM yet.'
,p_automatic_refresh_interval=>75
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(80029984491482575008)
,p_chart_id=>wwv_flow_imp.id(80029984312862575007)
,p_seq=>10
,p_name=>'Project Performance'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--pending/ halt/ overdue',
'select nvl((select project_name from projects p where p.project_id = pd.project_id),''Anonymous'') projects, nvl(sum(trunc(end_to - sysdate)+1),0) points',
'from project_details pd',
'where status in (0,2,3)',
'and project_id is not null',
'and (team_id = :P1_TEAM or :P1_TEAM is null)',
'group by project_id',
'order by points asc'))
,p_ajax_items_to_submit=>'P1_TEAM'
,p_items_value_column_name=>'POINTS'
,p_items_label_column_name=>'PROJECTS'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(80029984754635575011)
,p_chart_id=>wwv_flow_imp.id(80029984312862575007)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Projects'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(80029984841984575012)
,p_chart_id=>wwv_flow_imp.id(80029984312862575007)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Points'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80029987436410575038)
,p_plug_name=>'USERTASKS'
,p_parent_plug_id=>wwv_flow_imp.id(80029983746639575001)
,p_region_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="border-left: solid gray";'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80029986395134575027)
,p_plug_name=>'To Do'
,p_parent_plug_id=>wwv_flow_imp.id(80029987436410575038)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(80029986426883575028)
,p_region_id=>wwv_flow_imp.id(80029986395134575027)
,p_chart_type=>'donut'
,p_title=>'User Activities'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_no_data_found_message=>'No Activity of this TEAM yet.'
,p_automatic_refresh_interval=>80
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(80029986597375575029)
,p_chart_id=>wwv_flow_imp.id(80029986426883575028)
,p_seq=>10
,p_name=>'User Activities'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (select full_name||'' - ''||id_no from user_tables ap where ap.userid = ut.userid) appuser, count(*) total_tasks ',
'from user_tasks ut',
'where (team_id = :P1_TM or :P1_TM is null)',
'and proid in (select proid from project_details where (project_id = :P1_PRJKT or :P1_PRJKT is null) ',
'and (status = :P1_STS or :P1_STS is null))',
'group by userid;',
''))
,p_ajax_items_to_submit=>'P1_TM,P1_PRJKT,P1_STS'
,p_items_value_column_name=>'TOTAL_TASKS'
,p_items_label_column_name=>'APPUSER'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80029987537456575039)
,p_plug_name=>'PARAM'
,p_parent_plug_id=>wwv_flow_imp.id(80029987436410575038)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4393901274456484914)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3746351602753298601)
,p_button_name=>'Action'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(27645617343518606449)
,p_button_image_alt=>'Action'
,p_button_position=>'ABOVE_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-tasks'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4710160163955605401)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3746351602753298601)
,p_button_name=>'Add_New_Task'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645617343518606449)
,p_button_image_alt=>'Add New Task'
,p_button_position=>'ABOVE_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE IN (''1000'',''1001'') THEN',
'RETURN TRUE;',
'ELSE ',
'RETURN FALSE;',
'END IF;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-list fam-plus fam-is-success'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(78998280940420474322)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(78998280633317474319)
,p_button_name=>'Join'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Join'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::P41_TEAM_MEMBER_ID:1000'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(78998279712983474310)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(78998278800879474301)
,p_button_name=>'Add_New_Role'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Add New Role'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36500905124404055512)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(36500905076919055511)
,p_button_name=>'add_new_team'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--mobileHideLabel:t-Button--success:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(27645618115673606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add New Team'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-plus-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36500905203053055513)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(36500905076919055511)
,p_button_name=>'Join_a_team'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--mobileHideLabel:t-Button--primary:t-Button--iconRight:t-Button--hoverIconPush:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(27645618115673606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Join A Team'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RR,20::'
,p_icon_css_classes=>'fa-arrow-circle-o-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(78998280162049474314)
,p_branch_name=>'Go To Login'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(78998279712983474310)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2380531477279787612)
,p_name=>'P1_P_ACT_STS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2380531585429787613)
,p_item_default=>'Y'
,p_prompt=>'Activity'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Active;Y,Inactive;N'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78998278960032474302)
,p_name=>'P1_USERID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(78998278800879474301)
,p_prompt=>'User'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT full_name d, userid r ',
'FROM USER_TABLES',
'WHERE userid = :BIND_USER_ID'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78998279006610474303)
,p_name=>'P1_ROLEID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(78998278800879474301)
,p_prompt=>'Role'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT rolename d, roleid r',
'FROM ROLE_TABLES',
'WHERE roleid != 1000;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615373439606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80029984980860575013)
,p_name=>'P1_TEAM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(80029983819372575002)
,p_item_default=>':BIND_TEAM_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Select Team'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TEAM'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80029986879741575032)
,p_name=>'P1_TM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(80029987537456575039)
,p_item_default=>':BIND_TEAM_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Team'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TEAM'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80029986929837575033)
,p_name=>'P1_PRJKT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(80029987537456575039)
,p_prompt=>'Project'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROJECT_NAME||'': ''||TO_CHAR(CHECK_OUT,''DD-MON'') PROJECT_NAME , PROJECT_ID r',
'from PROJECTS ',
'where (TEAM_ID = :P1_TM)',
'AND STATUS IN (''Y'',''N'');'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P1_TM'
,p_ajax_items_to_submit=>'P1_TM'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80029987146188575035)
,p_name=>'P1_STS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(80029987537456575039)
,p_prompt=>'Activity'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PROJECT STATUS'
,p_lov=>'.'||wwv_flow_imp.id(27651661124332706306)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80029988134818575045)
,p_name=>'P1_P_TM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2380531585429787613)
,p_item_default=>':BIND_TEAM_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Team'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TEAM'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Select Team--'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80029988219372575046)
,p_name=>'P1_P_STS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2380531585429787613)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PROJECT STATUS'
,p_lov=>'.'||wwv_flow_imp.id(27651661124332706306)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--All Tasks--'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36500904783072055508)
,p_name=>'toOpenInlineConditionally'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(36500904007387055501)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36500904985227055510)
,p_event_id=>wwv_flow_imp.id(36500904783072055508)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''msg'');'
,p_server_condition_type=>'FUNCTION_BODY'
,p_server_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v__admin number;',
'begin',
'',
'select count(*)',
'into v__admin',
'from users_role',
'where userid = :BIND_USER_ID',
'and roleid = 1000;',
'',
'',
'for i in (select count(userid) usr from team_members where userid in :BIND_USER_ID) ',
'loop',
'if i.usr > 0 then',
'return false;',
'elsif i.usr <= 0 and v__admin > 0 then',
'return false;',
'elsif i.usr <= 0 then',
'return true;',
'end if;',
'end loop;',
'end;'))
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(78998279945216474312)
,p_name=>'ButtonAdjustment'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(78998280022778474313)
,p_event_id=>wwv_flow_imp.id(78998279945216474312)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.ITEMS.WITH.BUTTONS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(78998279712983474310)
,p_attribute_01=>'P1_ROLEID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(78998280436656474317)
,p_name=>'toOpenConditionally2'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(78998280399292474316)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(78998280556170474318)
,p_event_id=>wwv_flow_imp.id(78998280436656474317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Manual2'');'
,p_server_condition_type=>'FUNCTION_BODY'
,p_server_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v__newteam NUMBER;',
'BEGIN',
'SELECT COUNT(*)',
'INTO v__newteam',
'FROM team_members',
'WHERE team_member_id = 1000',
'and (team_id is null or userid is null);',
'IF v__newteam = 1 THEN',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;',
'END;'))
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80029985082215575014)
,p_name=>'PP'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_TEAM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80029985114708575015)
,p_event_id=>wwv_flow_imp.id(80029985082215575014)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(80029983819372575002)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80029986037577575024)
,p_name=>'UT'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_TEAM_ID,P1_PROJECT,P1_P_ACT_STS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80029987271478575036)
,p_name=>'UA'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_TM,P1_PRJKT,P1_STS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80029987317024575037)
,p_event_id=>wwv_flow_imp.id(80029987271478575036)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(80029986395134575027)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80029988367207575047)
,p_name=>'P'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_P_TM,P1_P_STS,P1_P_ACT_STS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80029988487853575048)
,p_event_id=>wwv_flow_imp.id(80029988367207575047)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(80029987666831575040)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(78998279881712474311)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'InsertRoleByUser'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'if :P1_ROLEID is not null and :P1_USERID is not null then',
'INSERT INTO USERS_ROLE (ROLEID, USERID)',
'VALUES (:P1_ROLEID, :P1_USERID);',
'else null;',
'end if;',
'COMMIT;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(78998279712983474310)
,p_internal_uid=>78998279881712474311
);
wwv_flow_imp.component_end;
end;
/
