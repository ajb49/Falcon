prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_page.create_page(
 p_id=>22
,p_name=>'Team'
,p_alias=>'TEAM'
,p_page_mode=>'MODAL'
,p_step_title=>'Team'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'MD.ASIFJAMIL5@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231015203102'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101251148070589821371)
,p_plug_name=>'Add New Team'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645478217567606384)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'TEAMS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101251151188841821374)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(27645481003320606385)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36306681519071268239)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(101251151188841821374)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36306681994796268239)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(101251151188841821374)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :BIND_USER_ROLE IN (''1000'') THEN',
'RETURN TRUE;',
'ELSE',
'RETURN FALSE;',
'END IF;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36306682305200268240)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(101251151188841821374)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P22_TEAM_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36306682777906268240)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(101251151188841821374)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27645618047236606449)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P22_TEAM_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(81094746486671680110)
,p_branch_name=>'Go To Page13'
,p_branch_action=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101251149488903821378)
,p_name=>'P22_TEAM_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101251148070589821371)
,p_item_source_plug_id=>wwv_flow_imp.id(101251148070589821371)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Team Id'
,p_source=>'TEAM_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101251149840665821378)
,p_name=>'P22_TEAM_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(101251148070589821371)
,p_item_source_plug_id=>wwv_flow_imp.id(101251148070589821371)
,p_prompt=>'Team'
,p_source=>'TEAM_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101251150316597821379)
,p_name=>'P22_TEAM_LEADER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(101251148070589821371)
,p_item_source_plug_id=>wwv_flow_imp.id(101251148070589821371)
,p_prompt=>'Team Leader'
,p_source=>'TEAM_LEADER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'USER_TABLES.USERNAME'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- SELECT full_name||'' (''||email||'')'' d, userid r',
'-- FROM user_tables',
'-- where status = ''Y''',
'-- order by 1 asc',
'',
'select distinct userid r, (select full_name||'' (''||email||'' - ''||id_no||'')'' d from user_tables ut where ut.userid = tm.userid and status = ''Y'') full_name ',
'from team_members tm',
'where team_id = :BIND_TEAM_ID',
'order by 2 asc, 2 nulls last;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101251150737125821379)
,p_name=>'P22_SUB_LEADER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(101251148070589821371)
,p_item_source_plug_id=>wwv_flow_imp.id(101251148070589821371)
,p_prompt=>'Sub Leader'
,p_source=>'SUB_LEADER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'USER_TABLES.USERNAME'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- SELECT full_name||'' (''||email||'')'' d, userid r',
'-- FROM user_tables',
'-- where status = ''Y''',
'-- order by 1 asc',
'',
'select distinct userid r, (select full_name||'' (''||email||'' - ''||id_no||'')'' d from user_tables ut where ut.userid = tm.userid and status = ''Y'') full_name ',
'from team_members tm',
'where team_id = :BIND_TEAM_ID',
'order by 2 asc, 2 nulls last;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27645615559763606448)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36306684198585268241)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(36306681519071268239)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36306684606933268241)
,p_event_id=>wwv_flow_imp.id(36306684198585268241)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81094746187082680107)
,p_name=>'RemoveTeam'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(36306681994796268239)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81094746256059680108)
,p_event_id=>wwv_flow_imp.id(81094746187082680107)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE USER_TASKS SET TEAM_ID = NULL WHERE TEAM_ID = :P22_TEAM_ID;',
'UPDATE PROJECT_DETAILS SET TEAM_ID = NULL WHERE TEAM_ID = :P22_TEAM_ID;',
'UPDATE PROJECTS SET TEAM_ID = NULL WHERE TEAM_ID = :P22_TEAM_ID;',
'DELETE FROM TEAM_MEMBERS WHERE TEAM_ID = :P22_TEAM_ID;',
'DELETE FROM TEAMS WHERE TEAM_ID = :P22_TEAM_ID;',
'END;'))
,p_attribute_02=>'P22_TEAM_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81094746314806680109)
,p_event_id=>wwv_flow_imp.id(81094746187082680107)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(36306683303236268240)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    NEW_PK            VARCHAR2 (30) :=  NULL;',
'BEGIN',
'',
'    SELECT MAX (team_id)',
'      INTO NEW_PK',
'      FROM teams;',
'    ',
'    IF NEW_PK IS NULL THEN',
'        NEW_PK := 1000;',
'    ELSE',
'        NEW_PK := NEW_PK + 1;',
'    END IF;',
'    ',
'    :P22_TEAM_ID := NEW_PK;',
'EXCEPTION',
' WHEN OTHERS THEN',
'   HTP.P(SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(36306682777906268240)
,p_internal_uid=>36306683303236268240
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(36306680801451268238)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(101251148070589821371)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Add New Team'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>36306680801451268238
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(36306683732164268241)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>36306683732164268241
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(36306680432979268238)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(101251148070589821371)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Add New Team'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>36306680432979268238
);
wwv_flow_imp.component_end;
end;
/
