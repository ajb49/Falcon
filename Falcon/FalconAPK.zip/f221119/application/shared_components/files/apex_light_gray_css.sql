prompt --application/shared_components/files/apex_light_gray_css
begin
--   Manifest
--     APP STATIC FILES: 221119
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E617065782D63616C2D6C696768742D67726179207B0D0A202020206261636B67726F756E642D636F6C6F723A20236433643364333B0D0A20202020626F726465722D636F6C6F723A20236433643364333B0D0A20202020666F6E742D66616D696C793A';
wwv_flow_imp.g_varchar2_table(2) := '20417269616C2C2048656C7665746963612C2073616E732D73657269663B0D0A20202020636F6C6F723A207267622839352C2038342C203834293B0D0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(3313734697660506055)
,p_file_name=>'apex_light_gray.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
