prompt --application/shared_components/files/region_color_min_css
begin
--   Manifest
--     APP STATIC FILES: 221119
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E726567696F6E2D636F6C7B6865696768743A313030253B6261636B67726F756E642D636F6C6F723A677261797D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(3401208161088356519)
,p_file_name=>'region-color.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
