prompt --application/shared_components/user_interface/lovs/project_status
begin
--   Manifest
--     PROJECT STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(27651661124332706306)
,p_lov_name=>'PROJECT STATUS'
,p_lov_query=>'.'||wwv_flow_imp.id(27651661124332706306)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(27651661480106706307)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Pending'
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(27651661834468706307)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Done'
,p_lov_return_value=>'1'
,p_lov_disp_cond_type=>'FUNCTION_BODY'
,p_lov_disp_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :BIND_USER_ROLE NOT IN (''1002'') THEN',
'RETURN TRUE;',
'ELSE RETURN FALSE;',
'END IF;'))
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(27651662290503706308)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Overdue'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(27651662693716706308)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Halt'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(35084982892953907848)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Cancel'
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(48132788708162821688)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Done'
,p_lov_return_value=>'5'
,p_lov_disp_cond_type=>'FUNCTION_BODY'
,p_lov_disp_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :BIND_USER_ROLE IN (''1002'') THEN',
'RETURN TRUE;',
'ELSE RETURN FALSE;',
'END IF;'))
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
