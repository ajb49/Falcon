prompt --application/shared_components/user_interface/lovs/role
begin
--   Manifest
--     ROLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(28283634149557307814)
,p_lov_name=>'ROLE'
,p_lov_query=>'SELECT ROLEID, ROLENAME FROM ROLE_TABLES;'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ROLEID'
,p_display_column_name=>'ROLENAME'
,p_default_sort_column_name=>'ROLENAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
