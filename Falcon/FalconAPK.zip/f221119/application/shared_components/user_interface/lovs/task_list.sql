prompt --application/shared_components/user_interface/lovs/task_list
begin
--   Manifest
--     TASK LIST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(28090599154033807129)
,p_lov_name=>'TASK LIST'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct proid, task_name||'' - ''||nvl((select project_name from projects i where j.project_id = i.project_id),''Anonymus'') task_name',
'FROM project_details j',
'where status not in (''1'',''4'')',
'and (project_id IN ((select project_id from project_details where proid IN (select proid from user_tasks where team_id = :BIND_TEAM_ID))) or project_id is null',
'or project_id in (select project_id from project_details where team_id = :BIND_TEAM_ID)',
' )',
'',
'order by proid desc;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'PROID'
,p_display_column_name=>'TASK_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'DESC'
);
wwv_flow_imp.component_end;
end;
/
