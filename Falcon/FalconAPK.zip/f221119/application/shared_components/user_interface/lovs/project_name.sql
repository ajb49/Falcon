prompt --application/shared_components/user_interface/lovs/project_name
begin
--   Manifest
--     PROJECT_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(27648500739927683671)
,p_lov_name=>'PROJECT_NAME'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROJECT_ID,  PROJECT_NAME',
'                    ||'': ''',
'                    ||TO_CHAR(CHECK_OUT,''DD-MON-YY'')',
'                    ||'' [ ''',
'                    ||(SELECT nvl(team_name,''No Team'') FROM teams WHERE teams.team_id = projects.team_id)',
'                    ||'' ]'' PROJECT_NAME ',
'from PROJECTS ',
'where (TEAM_ID = :BIND_TEAM_ID ',
'OR ',
'project_id in (SELECT project_id FROM projects WHERE project_id in (select project_id from project_details where proid in (select proid from user_tasks where userid = :BIND_USER_ID)))',
') ',
'AND STATUS IN (''Y'')',
'-- select PROJECT_ID, PROJECT_NAME||'': ''||TO_CHAR(CHECK_OUT,''DD-MON'') PROJECT_NAME ',
'-- from PROJECTS ',
'-- where (TEAM_ID = :BIND_TEAM_ID ',
'-- OR ',
'-- project_id in (SELECT project_id FROM projects WHERE project_id in (select project_id from project_details where proid in (select proid from user_tasks where userid = :BIND_USER_ID)))',
'-- ) ',
'-- AND STATUS IN (''Y'');'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'PROJECT_ID'
,p_display_column_name=>'PROJECT_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'PROJECT_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
