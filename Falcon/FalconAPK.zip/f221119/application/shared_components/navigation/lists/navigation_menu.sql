prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(27645442049400606364)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(27645736581481606523)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(28085210671813260745)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Content'
,p_list_item_icon=>'fa-external-link-square'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(28085427462077750457)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'To Do ( &BIND_TO_DO. )'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tasks-alt'
,p_parent_list_item_id=>wwv_flow_imp.id(28085210671813260745)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38203597431509310028)
,p_list_item_display_sequence=>35
,p_list_item_link_text=>'Halt ( &BIND_HALT. )'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-hand-stop-o'
,p_parent_list_item_id=>wwv_flow_imp.id(28085210671813260745)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29071924174271605937)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Juncture'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-padlock-unlock'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v__appBuilder NUMBER;',
'BEGIN',
'select count(*)',
'into v__appBuilder',
'from user_tables',
'where userid = :BIND_USER_ID and username = ''ajb'' ',
'and full_name = ''Asif Jamil'' ',
'and email = ''md.asifjamil5@gmail.com'' ',
'and cell = ''01990161239'' ',
'and id_no = ''1264481'';',
'IF v__appBuilder = 1 THEN',
'RETURN TRUE;',
'ELSE ',
'RETURN FALSE;',
'END IF;',
'',
'END;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(28085210671813260745)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48132519222229924830)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Task Approval ( &BIND_UNAPPROVAL_TASK. )'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-check'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :BIND_USER_ID = :BIND_TEAM_LEADER OR :BIND_USER_ROLE IN (''1000'',''1001'') THEN',
'RETURN TRUE;',
'ELSE RETURN FALSE;',
'END IF;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(28085210671813260745)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'32'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29484692908947890167)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Project'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE IN (''1002'') THEN',
'RETURN FALSE;',
'ELSE',
'RETURN TRUE;',
'END IF;',
'END;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29044452268142983780)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Project'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gears'
,p_parent_list_item_id=>wwv_flow_imp.id(29484692908947890167)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(32249321364690361396)
,p_list_item_display_sequence=>36
,p_list_item_link_text=>'Team'
,p_list_item_icon=>'fa-users-alt'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE IN (''1002'') THEN',
'RETURN FALSE;',
'ELSE',
'RETURN TRUE;',
'END IF;',
'END;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29485612038468430879)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Team'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-futbol-o'
,p_parent_list_item_id=>wwv_flow_imp.id(32249321364690361396)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29487273359169014704)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Add Members'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-plus'
,p_parent_list_item_id=>wwv_flow_imp.id(32249321364690361396)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(28085274086877268476)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'User Authentication'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :BIND_USER_ROLE in (1000) THEN',
'RETURN TRUE;',
'ELSE ',
'RETURN FALSE;',
'END IF;',
'',
'END;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(28282404946617732678)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'User Preview'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_parent_list_item_id=>wwv_flow_imp.id(28085274086877268476)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(28284062502940319003)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'User Activities'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bicycle'
,p_parent_list_item_id=>wwv_flow_imp.id(28085274086877268476)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(28282536608414766093)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Roles Preview'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tag'
,p_parent_list_item_id=>wwv_flow_imp.id(28085274086877268476)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_imp.component_end;
end;
/
