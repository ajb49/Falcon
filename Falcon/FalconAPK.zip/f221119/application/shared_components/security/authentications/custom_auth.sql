prompt --application/shared_components/security/authentications/custom_auth
begin
--   Manifest
--     AUTHENTICATION: Custom_Auth
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(28059932936877762722)
,p_name=>'Custom_Auth'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'GET_IDENTITY'
,p_attribute_05=>'N'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
