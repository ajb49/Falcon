prompt --application/shared_components/logic/application_items/bind_team_name
begin
--   Manifest
--     APPLICATION ITEM: BIND_TEAM_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(36587956191545475077)
,p_name=>'BIND_TEAM_NAME'
,p_protection_level=>'I'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
