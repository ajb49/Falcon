prompt --application/user_interfaces
begin
--   Manifest
--     USER INTERFACES: 221119
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-20'
,p_default_workspace_id=>44255044500303736655
,p_default_application_id=>221119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKDUMP2'
);
wwv_flow_imp_shared.create_user_interface(
 p_id=>wwv_flow_imp.id(221119)
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_login_url=>'f?p=&APP_ID.:LOGIN:&APP_SESSION.::&DEBUG.:::'
,p_theme_style_by_user_pref=>false
,p_built_with_love=>false
,p_global_page_id=>0
,p_navigation_list_id=>wwv_flow_imp.id(27645442049400606364)
,p_navigation_list_position=>'TOP'
,p_navigation_list_template_id=>wwv_flow_imp.id(27645611295940606446)
,p_nav_list_template_options=>'#DEFAULT#:js-tabLike'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#wallpaperflare.com_wallpaper.jpg',
'#APP_FILES#app_icon.css',
'#APP_FILES#app-221119-logo.png',
'#APP_FILES#apex_light_gray.css',
'#APP_FILES#region-color.css',
'#APP_FILES#hover-badge-effect.css'))
,p_nav_bar_type=>'LIST'
,p_nav_bar_list_id=>wwv_flow_imp.id(27645725916739606511)
,p_nav_bar_list_template_id=>wwv_flow_imp.id(27645605442154606443)
,p_nav_bar_template_options=>'#DEFAULT#'
);
wwv_flow_imp.component_end;
end;
/
